package edu.ccnu.tools.weka;

import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;
import org.deeplearning4j.models.embeddings.loader.WordVectorSerializer;
import org.deeplearning4j.models.word2vec.Word2Vec;

public class POS2VecHandler {
	private String modelPath;
	private Word2Vec word2Vec;
	private double[] baseVec;
	private static POS2VecHandler pos2VecHandler=null;
	
	/**  
	 * <p>Title: getPOS2VecHandler</p>  
	 * <p>Description: </p>  
	 * @param modelPath
	 * @return  
	 */  
	public static POS2VecHandler getPOS2VecHandler(String modelPath) {
		if (pos2VecHandler == null) {
			synchronized (POS2VecHandler.class) {
				if (pos2VecHandler == null) {
					pos2VecHandler=new POS2VecHandler(modelPath);
				}
			}
		}
		return pos2VecHandler;
	}
	
	private POS2VecHandler (String modelPath) {
		this.modelPath=modelPath;
		setWord2Vec();
		setBaseVec();
	}
	
	public double getPOSCosineValue(String pos) {
		double[] posVec=word2Vec.getWordVector(pos);
		if (posVec==null) {
			posVec=new double[word2Vec.vectorSize()];
			return 0;
		}
		RealVector realVector1=new ArrayRealVector(posVec);
		RealVector realVector2=new ArrayRealVector(baseVec);
		return realVector1.cosine(realVector2);
	}
	
	
	public Word2Vec getWord2Vec() {
		return word2Vec;
	}
	public void setWord2Vec() {
		word2Vec=WordVectorSerializer.readWord2VecModel(modelPath);
	}
	public String getModelPath() {
		return modelPath;
	}
	public void setModelPath(String modelPath) {
		this.modelPath = modelPath;
	}
	public double[] getBaseVec() {
		return baseVec;
	}
	public void setBaseVec() {
		baseVec=new double[word2Vec.vectorSize()];
		for (int i = 0; i < baseVec.length; i++) {
			baseVec[i]=1.0;
		}
	}
}
