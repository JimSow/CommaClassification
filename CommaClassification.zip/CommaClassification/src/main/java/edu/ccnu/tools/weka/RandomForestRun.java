package edu.ccnu.tools.weka;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.Random;

import javax.swing.JFrame;

import fr.ign.cogit.roc4j.core.AreaUnderCurve;
import fr.ign.cogit.roc4j.core.ReceiverOperatingCharacteristics;
import fr.ign.cogit.roc4j.core.RocCurvesCollection;
import fr.ign.cogit.roc4j.graphics.ColorMap;
import fr.ign.cogit.roc4j.graphics.RocSpace;
import fr.ign.cogit.roc4j.utils.Tools;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.evaluation.ThresholdCurve;
import weka.classifiers.functions.Logistic;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.SerializationHelper;
import weka.core.Utils;
import weka.core.converters.ConverterUtils.DataSink;
import weka.gui.visualize.PlotData2D;
import weka.gui.visualize.ThresholdVisualizePanel;

public class RandomForestRun {
	static String username = "root";
	static String password = "hjx123456789";
	static String dburl = "jdbc:mysql://127.0.0.1:3306/mathwordproblems" + "?useUnicode=true&characterEncoding=UTF8";
	
	private static Color[] colors= {Color.BLUE,Color.GREEN,Color.ORANGE,Color.RED};
	public static void main(String[] args) throws Exception {
		/*
		 * 从数据库中加载数据
		 */
		
//		baselineEvaluations();
		validatePK4SMOTE();
	}
	
	
	private static void validatePK4SMOTE() throws Exception {
		RandomForest optimalRF=(RandomForest) SerializationHelper.read("./models/RF.model");
		RandomForest evalRF=new RandomForest();
		evalRF.setOptions(optimalRF.getOptions());
		
		//loading data
		//data preprocessing
		Instances data=preProcessingData();
		data.randomize(new Random(1));
		//split the dataset into training set and testing set
		int trainSize = (int) Math.round(data.numInstances() * 0.75);  
        int testSize = data.numInstances() - trainSize;  
        Instances train = new Instances(data, 0, trainSize);  
        Instances test = new Instances(data, trainSize, testSize);
        
        int K=4;
        for(int i=1;i<=5;i++) {
        	int P=100*i;
        	Instances balanceTrainData=balanceData(train,P,K);
        	evalRF.buildClassifier(balanceTrainData);
//    		Evaluation evaluation=WekaUtils.crossValidate(evalRF, balanceTrainData, 10);
    		Evaluation evaluation=new Evaluation(train);
    		evaluation.evaluateModel(evalRF, test);
    		System.out.println("当P="+P+"，K="+K+"时:…………………………………………………………………………………………………………………");
    		outputEvaluation(evaluation);
        }
        
	}


	private static void baselineEvaluations() throws Exception {
		//data preprocessing
		Instances data=preProcessingData();
		data.randomize(new Random(1));
		
		//split the dataset into training set and testing set
		int trainSize = (int) Math.round(data.numInstances() * 0.75);  
        int testSize = data.numInstances() - trainSize;  
        Instances train = new Instances(data, 0, trainSize);  
        Instances test = new Instances(data, trainSize, testSize);
        
        Instances balanceTrainData=balanceData(train);
		
		
		//optimization parameters in the classifiers 
		Classifier[] classifiers=new Classifier[3];
		RandomForest rf = new RandomForest();
		Logistic logistic=new Logistic();
		J48 j48=new J48();
		classifiers[0]=logistic;
		classifiers[1]=j48;
		classifiers[2]=rf;
		WekaUtils.optimizeClassifiers(classifiers, train);
//		System.out.println(classifiers[2]);
		//10-fold cross-validation on the training set
		Evaluation[] evaluations=WekaUtils.evaluateClassifiers(classifiers, train, 10);
		//RF+SMOTE
		RandomForest balanceRF=new RandomForest();
		balanceRF.setOptions(rf.getOptions());
		balanceRF.buildClassifier(balanceTrainData);
		Evaluation eval4RForestAndSMOTE=WekaUtils.crossValidate(balanceRF, balanceTrainData, 10);
		
		
		System.out.println("Logistics classifier:……………………………………………………………………………………………………………");
		/**cross-validation**/
		outputEvaluation(evaluations[0]);
		SerializationHelper.write("./models/Logistics.model",classifiers[0]);
		/**test set**/
//		Evaluation evalTestSet1=new Evaluation(train);
//		evalTestSet1.evaluateModel(classifiers[0], test);
//		outputEvaluation(evalTestSet1);
		
		
		System.out.println("J8 classifier:………………………………………………………………………………………………………………………………");
		/**cross-validation**/
		outputEvaluation(evaluations[1]);
		SerializationHelper.write("./models/J8.model",classifiers[1]);
		/**test set**/
//		Evaluation evalTestSet2=new Evaluation(train);
//		evalTestSet2.evaluateModel(classifiers[1], test);
//		outputEvaluation(evalTestSet2);
		
		
		System.out.println("RF classifier:………………………………………………………………………………………………………………………………");
		/**cross-validation**/
		outputEvaluation(evaluations[2]);
		SerializationHelper.write("./models/RF.model",classifiers[2]);
		/**test set**/
//		Evaluation evalTestSet3=new Evaluation(train);
//		evalTestSet3.evaluateModel(classifiers[2], test);
//		outputEvaluation(evalTestSet3);
		
		
		/**cross-validation**/
		System.out.println("RF+SMOTE classifier:………………………………………………………………………………………………………………………………");
		outputEvaluation(eval4RForestAndSMOTE);
		SerializationHelper.write("./models/RF-SMOTE.model",balanceRF);
		/**test set**/
//		Evaluation evalTestSet4=new Evaluation(train);
//		evalTestSet4.evaluateModel(balanceRF, test);
//		outputEvaluation(evalTestSet4);
		
		//visualizing the ROC curve
//		Evaluation[] evaluations2= {evalTestSet1,evalTestSet2,evalTestSet3};
		visualizeRocCurveCollection(evaluations, eval4RForestAndSMOTE);
	}

	private static void visualizeRocCurveCollection(Evaluation[] evaluations, Evaluation compareEval) {
		RocCurvesCollection curvesCollection=new RocCurvesCollection(true);
		ThresholdCurve tc = new ThresholdCurve();
		int classIndex = 1;
		int colorIndex=0;
		for (Evaluation evaluation : evaluations) {
			ReceiverOperatingCharacteristics roc = rocFromEvaluation(evaluation, tc, classIndex);
			curvesCollection.add(roc);
			roc.setThickness(1.5f);
			roc.setColor(colors[colorIndex]);
			colorIndex++;
		}
		ReceiverOperatingCharacteristics compareROC=rocFromEvaluation(compareEval, tc, classIndex);
		compareROC.setColor(colors[colorIndex]);
		compareROC.setThickness(1.5f);
		curvesCollection.add(compareROC);
		
		RocSpace space = new RocSpace();
		space.setTitle("ROC curve for the baseline: J48, Logistic,RF,RF-SMOTE");
		space.setXLabel("False Positive Rate");
		space.setYLabel("True Positive Rate");
		space.addRocCurve(curvesCollection);
		space.writeText("Logistics", 450, 450, 20,colors[0]);
		space.writeText("J48", 450, 475, 20,colors[1]);
		space.writeText("RF", 450, 500, 20,colors[2]);
		space.writeText("RF-SMOTE", 450, 525, 20,colors[3]);
		
		JFrame fen = new JFrame();
		fen.setSize(700, 700);
		fen.setContentPane(space);
		fen.setLocationRelativeTo(null);
		fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fen.setVisible(true);
		
	}

	private static ReceiverOperatingCharacteristics rocFromEvaluation(Evaluation evaluation, ThresholdCurve tc,
			int classIndex) {
		Instances result = tc.getCurve(evaluation.predictions(), classIndex);
		int tpIndex = result.attribute(ThresholdCurve.TP_RATE_NAME).index();
		int fpIndex = result.attribute(ThresholdCurve.FP_RATE_NAME).index();
		double[] tpRate = result.attributeToDoubleArray(tpIndex);
		double[] fpRate = result.attributeToDoubleArray(fpIndex);
		ReceiverOperatingCharacteristics roc=new ReceiverOperatingCharacteristics(fpRate,tpRate);
		return roc;
	}

	private static Instances preProcessingData() throws Exception {
	
		String sql = "select * from stratifiedcommafeature";
		Instances data = WekaUtils.loadInstancesFromDB(username, password, dburl, sql);
		/*
		 * 特征工程
		 */
		// 删除mwpId属性
		Instances newData = FeatureEngineeringUtils.useRemoveFilter(data, "1");
		// 生成交叉特征
		newData = FeatureEngineeringUtils.generateCrossingFeature(newData);
		// 把newData中的string属性转换nominal属性
		newData = FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes() - 3));
		newData = FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes() - 2));
		newData.setRelationName("data");
		return newData;
	}
	private static Instances balanceData(Instances data) throws Exception {
//		String[] options = { "-S", "1", "-P", "100.0", "-K", "3" };
//		Instances newData = FeatureEngineeringUtils.useSMOTE(data, options);
//		newData.setRelationName("training balanced data");
		return balanceData(data,100,3);
	}
	private static Instances balanceData(Instances data, int P,int K) throws Exception {
		String[] options = { "-S", "1", "-P", ""+P, "-K", ""+K };
		Instances newData = FeatureEngineeringUtils.useSMOTE(data, options);
		newData.setRelationName("training balanced data");
		return newData;
	}
	
	
	private static Instances preProcessingTestData() throws Exception {
		String sql = "select * from stratifiedcommafeature where mwpId>235";
		Instances data = WekaUtils.loadInstancesFromDB(username, password, dburl, sql);
		/*
		 * 特征工程
		 */
		// 删除mwpId属性
		Instances newData = FeatureEngineeringUtils.useRemoveFilter(data, "1");
		// 生成交叉特征
		newData = FeatureEngineeringUtils.generateCrossingFeature(newData);
		// 把newData中的string属性转换nominal属性
		newData = FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes() - 3));
		newData = FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes() - 2));
		newData.setRelationName("testing data");
		return newData;
	}

	private static void buildClassifier4SMOTE() throws Exception {
		/*
		 * 从数据库中加载数据
		 */
		String username = "root";
		String password = "hjx123456789";
		String dburl = "jdbc:mysql://127.0.0.1:3306/mathwordproblems" + "?useUnicode=true&characterEncoding=UTF8";
		String sql = "select * from stratifiedcommafeature";
		Instances data = WekaUtils.loadInstancesFromDB(username, password, dburl, sql);
		/*
		 * 特征工程
		 */
		// 删除mwpId属性
		Instances newData = FeatureEngineeringUtils.useRemoveFilter(data, "1");
		// 生成交叉特征
		newData = FeatureEngineeringUtils.generateCrossingFeature(newData);
		// 把newData中的string属性转换nominal属性
		newData = FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes() - 3));
		newData = FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes() - 2));
		// //newData出现imbalance，使用SMOTE进行过采样
		for(int i=1;i<=5;i++) {
			double P=100.0*i;
			String[] options = { "-S", "1", "-P", ""+P, "-K", "3" };
			Instances oversamplingData = FeatureEngineeringUtils.useSMOTE(newData, options);
			oversamplingData.setRelationName("oversamplingData");
			System.out.println(oversamplingData.toSummaryString());
			FeatureEngineeringUtils.ClassStatistics(oversamplingData);
			/*
			 * randomforest 参数优化
			 */
			RandomForest rf = new RandomForest();
			Classifier[] classifiers = new Classifier[1];
			classifiers[0] = rf;
			WekaUtils.optimizeClassifiers(classifiers, oversamplingData);
			System.out.println("参数优化后的randomforest分类器：" + classifiers[0]);
			SerializationHelper.write("./models/commaRandomForest-P"+P+"-K"+3+".model",classifiers[0]);
		}
		// RandomForest rf=(RandomForest)
		// SerializationHelper.read("./models/commaRandomForest-P100.model");
		/*
		 * 10-cross-validation
		 */
		// Evaluation evaluation=WekaUtils.crossValidate(classifiers[0], newData, 10);
//		Evaluation evaluation = WekaUtils.crossValidate(rf, newData, 10);

		/*
		 * output evaluation
		 */
//		outputEvaluation(evaluation);

		/*
		 * visualization of ROC
		 */
//		visualizeROC4J(evaluation);
		
	}

	private static void outputEvaluation(Evaluation evaluation) throws Exception {
		System.out.println(evaluation.toSummaryString(false));
		System.out.println(evaluation.toClassDetailsString());
		System.out.println(evaluation.toMatrixString());
	}
	
	

	private static void visualizeROC4J(Evaluation evaluation) {
		ThresholdCurve tc = new ThresholdCurve();
		int classIndex = 1;
		Instances result = tc.getCurve(evaluation.predictions(), classIndex);
		int tpIndex = result.attribute(ThresholdCurve.TP_RATE_NAME).index();
		int fpIndex = result.attribute(ThresholdCurve.FP_RATE_NAME).index();
		double[] tpRate = result.attributeToDoubleArray(tpIndex);
		double[] fpRate = result.attributeToDoubleArray(fpIndex);
		ReceiverOperatingCharacteristics roc=new ReceiverOperatingCharacteristics(fpRate,tpRate);
//		ReceiverOperatingCharacteristics smoothRoc=roc.copy();
//		smoothRoc.smooth(ReceiverOperatingCharacteristics.SMOOTH_BINORMAL_REGRESSION);
//		smoothRoc.setColor(Color.GREEN);
		
		RocSpace space = new RocSpace();
		space.setTitle("Area Under Curve");
		space.setXLabel("False Positive Rate");
		space.setYLabel("True Positive Rate");
		String text = Tools.round(100*roc.computeAUC(), 2)+" %";
		int x = 450;
		int y = 450;
		space.writeText(text, x, y, 20, Color.GREEN.darker().darker());
		space.addRocCurve(roc);
//		space.addRocCurve(smoothRoc);
		
		JFrame fen = new JFrame();
		fen.setSize(700, 700);
		fen.setContentPane(space);
		fen.setLocationRelativeTo(null);
		fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fen.setVisible(true);
	}
	
	/**
	 * 生成weka内置的ROC曲线
	 * @param evaluation
	 * @throws Exception
	 */
	private static void visualizeROC(Evaluation evaluation) throws Exception {
		ThresholdCurve tc = new ThresholdCurve();

		// classIndex is the index of the class to consider as "positive"
		int classIndex = 0;
		Instances result = tc.getCurve(evaluation.predictions(), classIndex);
		System.out.println("The area under the ROC　curve: " + evaluation.areaUnderROC(classIndex));

		/*
		 * 在这里我们通过结果信息Instances对象得到包含TP、FP的两个数组 这两个数组用于在SPSS中通过线图绘制ROC曲面
		 */
		int tpIndex = result.attribute(ThresholdCurve.TP_RATE_NAME).index();
		int fpIndex = result.attribute(ThresholdCurve.FP_RATE_NAME).index();
		double[] tpRate = result.attributeToDoubleArray(tpIndex);
		double[] fpRate = result.attributeToDoubleArray(fpIndex);
//		DataSink.write("C:\\\\Users\\\\admin\\\\Desktop\\\\roc.csv", result);
		/*
		 * 使用结果信息instances对象来显示ROC曲面
		 */
		ThresholdVisualizePanel vmc = new ThresholdVisualizePanel();

		// 这个获得AUC的方式与上面的不同，其实得到的都是一个共同的结果
		vmc.setROCString("(Area under ROC = " + Utils.doubleToString(ThresholdCurve.getROCArea(result), 4) + ")");
		vmc.setName(result.relationName());
		PlotData2D tempd = new PlotData2D(result);
		tempd.setPlotName(result.relationName());
		tempd.addInstanceNumberAttribute();
		vmc.addPlot(tempd);

		// 显示曲面
		String plotName = vmc.getName();
		final javax.swing.JFrame jf = new javax.swing.JFrame("Weka Classifier Visualize: " + plotName);
		jf.setSize(500, 400);
		jf.getContentPane().setLayout(new BorderLayout());
		jf.getContentPane().add(vmc, BorderLayout.CENTER);
		jf.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				jf.dispose();
			}
		});
		jf.setVisible(true);
	}

}
