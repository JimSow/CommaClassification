package edu.ccnu.tools.weka;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.supervised.instance.SMOTE;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.unsupervised.attribute.StringToNominal;
import weka.filters.unsupervised.instance.Resample;
import weka.filters.unsupervised.instance.SubsetByExpression;

public class FeatureEngineeringUtils {
	/**
	 * 数据预处理阶段，生成交叉特征
	 * 
	 * @param newData
	 *            生成交叉特征
	 * @return
	 * @throws Exception
	 */
	public static Instances generateCrossingFeature(Instances newData) throws Exception {
		Attribute preTermNLAtt = new Attribute("preTermNL", (ArrayList<String>) null);
		Attribute nextTermNLAtt = new Attribute("nextTermNL", (ArrayList<String>) null);
		ArrayList<String> preNextClauseDLList = new ArrayList<>();
		preNextClauseDLList.add("00");
		preNextClauseDLList.add("11");
		preNextClauseDLList.add("01");
		preNextClauseDLList.add("10");
		Attribute preNextClauseDLAtt = new Attribute("preNextClauseDL", preNextClauseDLList);
		newData.insertAttributeAt(preTermNLAtt, newData.numAttributes() - 1);
		newData.insertAttributeAt(nextTermNLAtt, newData.numAttributes() - 1);
		newData.insertAttributeAt(preNextClauseDLAtt, newData.numAttributes() - 1);
		newData.randomize(new Random((long) 6.66));
		newData.setClassIndex(newData.numAttributes() - 1);
		for (int i = 0; i < newData.numInstances(); i++) {
			Instance instance = newData.get(i);
			String preTermNL = instance.stringValue(1) + (int) instance.value(2);
			String nextTermNL = instance.stringValue(3) + (int) instance.value(4);
			String preNextClauseDL = "" + (int) instance.value(7) + (int) instance.value(8);
			instance.setValue(newData.numAttributes() - 2, preNextClauseDL);
			instance.setValue(newData.numAttributes() - 3, nextTermNL);
			instance.setValue(newData.numAttributes() - 4, preTermNL);
		}
		// DataSink.write("C:\\Users\\admin\\Desktop\\comma-20171010.arff", newData);
		return newData;
	}

	public static void outputAttributes(Instances data) {
		Enumeration<Attribute> attributes = data.enumerateAttributes();
		while (attributes.hasMoreElements()) {
			Attribute attribute = (Attribute) attributes.nextElement();
			System.out.println(attribute);
		}
	}

	/**
	 * 数据预处理阶段，特征初步选择
	 * 
	 * @param data
	 * @param attributeIndex
	 *            移除属性的索引，从1开始
	 * @return
	 * @throws Exception
	 */
	public static Instances useRemoveFilter(Instances data, String attributeIndex) throws Exception {
		Filter removeFilter = new Remove();
		String[] options = new String[2]; // 设置移除的属性
		options[0] = "-R";
		options[1] = attributeIndex;
		removeFilter.setOptions(options);
		removeFilter.setInputFormat(data);
		Instances newData = Filter.useFilter(data, removeFilter);
		return newData;
	}
	
	/**  
	 * <p>Title: removeAttributes</p>  
	 * <p>Description: </p>  
	 * @param instance
	 * @param removeAttrIndexList  
	 */  
	public static void removeAttributes(Instance instance, List<Integer> removeAttrIndexList) {
		for (int i =instance.numAttributes()-1; i >-1; i--) {
			if (removeAttrIndexList.contains(i)) {
				instance.deleteAttributeAt(i);
			}
		}
	}
	
	/**  
	 * <p>Title: removeAttributes</p>  
	 * <p>Description: </p>  
	 * @param instances
	 * @param removeAttrIndexList  
	 */  
	public static void removeAttributes(Instances instances, List<Integer> removeAttrIndexList) {
		for (int i =instances.numAttributes()-1; i >-1; i--) {
			if (removeAttrIndexList.contains(i)) {
				instances.deleteAttributeAt(i);
			}
		}
	}

	/**
	 * <p>
	 * Title: useSubsetByExpressionFilter
	 * </p>
	 * <p>
	 * Description: 根据表达式筛选数据
	 * </p>
	 * 
	 * @param data
	 * @param expression
	 * 
	 *            Examples: 
	 *            		- extracting only mammals and birds from the 'zoo' UCI
	 *           	 dataset: (CLASS is 'mammal') or (CLASS is 'bird') 
	 *            		- extracting
	 *        		 only animals with at least 2 legs from the 'zoo' UCI dataset:
	 *           	 (ATT14 >= 2) 
	 *            		- extracting only instances with non-missing
	 *            	 'wage-increase-second-year' from the 'labor' UCI dataset: not
	 *            	 ismissing(ATT3)
	 * 
	 * @return
	 * @throws Exception
	 */
	public static Instances useSubsetByExpressionFilter(Instances data, String expression) throws Exception {
		Filter subsetByExpressionFilter = new SubsetByExpression();
		String[] options = new String[2]; // 设置筛选的表达式
		options[0] = "-E";
		options[1] = expression;
		subsetByExpressionFilter.setOptions(options);
		subsetByExpressionFilter.setInputFormat(data);
		return Filter.useFilter(data, subsetByExpressionFilter);
	}

	/**
	 * 预处理阶段，对指定的string属性转换成nominal属性
	 * 
	 * @param data
	 * @param attributeIndex
	 *            把string属性转换成nominal属性
	 * @return
	 * @throws Exception
	 */
	public static Instances useString2NominalFilter(Instances data, String attributeIndex) throws Exception {
		Filter string2NominalFilter = new StringToNominal();
		String[] options = new String[2]; // 设置移除的属性
		options[0] = "-R";
		options[1] = attributeIndex;
		string2NominalFilter.setOptions(options);
		string2NominalFilter.setInputFormat(data);
		Instances newData = Filter.useFilter(data, string2NominalFilter);
		return newData;
	}

	/**
	 * 利用SMOTE对imbalance数据进行过采样，SMOTE原理见“SMOTE: Synthetic Minority Over-sampling
	 * Technique” 可以避免resample出现过拟合问题
	 * 
	 * @param data
	 * @param options
	 *            如 options= {"-S","1","-P","100.0","-K","5"};
	 * @return
	 * @throws Exception
	 */
	public static Instances useSMOTE(Instances data, String[] options) throws Exception {
		SMOTE smote = new SMOTE();
		smote.setOptions(options);
		smote.setInputFormat(data);
		Instances newData = Filter.useFilter(data, smote);
		return newData;
	}
	
	public static Instances useForestSMOTE(Instances data, String[] options) throws Exception {
		String eosIForestModel="F:/语料/人民日报语料/2014/iForest-EOSCommas.model";
		String noneosIForestModel="F:/语料/人民日报语料/2014/iForest-NONEOSCommas.model";	
		String pos2vecModelPath="F:/语料/人民日报语料/2014/pos_vectors_300.bin";
		
		IsolationForestOutlierValidator forestOutlierValidator1=new IsolationForestOutlierValidator(noneosIForestModel, pos2vecModelPath, 0.3);
		IsolationForestOutlierValidator forestOutlierValidator2=new IsolationForestOutlierValidator(eosIForestModel, pos2vecModelPath, 0.3);
		HashMap<IOutlierValidator, Boolean> outlierMap=new HashMap<>();
		outlierMap.put(forestOutlierValidator1, false);
		outlierMap.put(forestOutlierValidator2, true);
		ForestSMOTE forestSmote=new ForestSMOTE(outlierMap);
		forestSmote.setOptions(options);
		forestSmote.setInputFormat(data);
		Instances newData=Filter.useFilter(data, forestSmote);
		return newData;
	}

	/**
	 * 对imbalance数据进行过采样，复制式，容易产生过拟合
	 * 
	 * @param data
	 * @param options
	 *            如 options={"-S","1"};
	 * @return
	 * @throws Exception
	 */
	public static Instances useResample(Instances data, String[] options) throws Exception {
		Resample resample = new Resample();
		resample.setOptions(options);
		resample.setInputFormat(data);
		Instances newData = Filter.useFilter(data, resample);
		return newData;
	}

	public static void ClassStatistics(Instances data) {
		int eos = 0;
		int noneos = 0;
		for (Instance instance : data) {
			String clazz = instance.stringValue(instance.classIndex());
			if (clazz.equalsIgnoreCase("eos")) {
				eos++;
			} else if (clazz.equalsIgnoreCase("noneos")) {
				noneos++;
			}
		}
		System.out.println("EOS:" + eos + "\t" + "NONEOS:" + noneos);
	}

}
