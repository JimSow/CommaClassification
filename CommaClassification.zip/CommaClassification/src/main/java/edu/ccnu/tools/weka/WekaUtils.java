package edu.ccnu.tools.weka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

import weka.attributeSelection.BestFirst;
import weka.attributeSelection.CfsSubsetEval;
import weka.classifiers.Classifier;
import weka.classifiers.CostMatrix;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.classifiers.functions.SMO;
import weka.classifiers.functions.supportVector.RBFKernel;
import weka.classifiers.lazy.IBk;
import weka.classifiers.meta.AdaBoostM1;
import weka.classifiers.meta.Bagging;
import weka.classifiers.meta.CVParameterSelection;
import weka.classifiers.meta.CostSensitiveClassifier;
import weka.classifiers.meta.LogitBoost;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.LMT;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.Utils;
import weka.core.converters.ArffSaver;
import weka.experiment.InstanceQuery;
import weka.filters.Filter;
import weka.filters.supervised.attribute.AttributeSelection;
import weka.filters.unsupervised.attribute.PrincipalComponents;
import weka.filters.unsupervised.instance.RemovePercentage;


public class WekaUtils {

	/**
	 * Load instances from .arff file
	 * @param filename the name of the .arff file
	 * @return the set of instances
	 * @throws Exception
	 */
	public static Instances loadInstances(String filename) throws Exception {
		BufferedReader reader = new BufferedReader(new FileReader(filename));
		Instances data = new Instances(reader);
		reader.close();
		data.setClassIndex(data.numAttributes() - 1);
		return data;
	}
	
	/**  
	 * <p>Title: loadInstancesFromDB</p>  
	 * <p>Description: 从数据库中读取数据</p>  
	 * @param DbUserName
	 * @param DbPassword
	 * @param DbUrl
	 * @param querySql
	 * @return
	 * @throws Exception  
	 */  
	public static Instances loadInstancesFromDB(String DbUserName,String DbPassword,
			String DbUrl,String querySql) throws Exception {
		InstanceQuery query=new InstanceQuery();
		query.setUsername(DbUserName);
		query.setPassword(DbPassword);
		query.setDatabaseURL(DbUrl);
		query.setDebug(true);
		query.setQuery(querySql);
		Instances data=query.retrieveInstances();
		return data;
	}
	
	public static void saveArff(String arffPath, Instances data) throws IOException {
		ArffSaver saver=new ArffSaver();
		saver.setFile(new File(arffPath));
		saver.setInstances(data);
		saver.writeBatch();
	}
	
	/**
	 * Use CfsSubsetEval to find a good subset of features using 
	 * correlation-based feature selection before classifying
	 * @param data the set of instances to be passed through the filter
	 * @return the dataset with only the selected features
	 * @throws Exception if the dataset is null
	 */
	public static Instances selectFeaturesCFS(Instances data) throws Exception {
		AttributeSelection filter = new AttributeSelection();
		CfsSubsetEval cfsEval = new CfsSubsetEval();
		BestFirst search = new BestFirst();
		search.setSearchTermination(50);

		filter.setEvaluator(cfsEval);
		filter.setSearch(search);
		filter.setInputFormat(data);
		return Filter.useFilter(data, filter);
	}
	
	/**
	 * Run PCA on the dataset, using cross-validation to decide the number of components
	 * Useful for quick dimension reduction
	 * @param data
	 * @return the principal components
	 * @throws Exception if data is null
	 */
	public static Instances PCA(Instances data) throws Exception{
		PrincipalComponents pca = new PrincipalComponents();
		pca.setInputFormat(data);
		return Filter.useFilter(data, pca);
	}
	
	/**
	 * Evaluate a CostSensitiveClassifier model on a dataset with cross-validation
	 * @param classifier  the base classifier for CostSensitiveClassifer
	 * @param data 	the set of instances
	 * @param costMatrix	the cost matrix within the CostSensitiveClassifer	
	 * @param folds the number of cross-validation folds
	 * @return the evaluation result
	 * @throws Exception
	 */
	public static Evaluation crossValidateCSClassifier(Classifier classifier, Instances data, 
			CostMatrix costMatrix,int folds) throws Exception {
		CostSensitiveClassifier csc=new CostSensitiveClassifier();
		csc.setClassifier(classifier);
		csc.setCostMatrix(costMatrix);
		csc.buildClassifier(data);
		Evaluation eval=new Evaluation(data, csc.getCostMatrix());
		eval.crossValidateModel(csc, data, folds, new Random(1));
		return eval;
	}
	
	
	/**
	 * Evaluate a model on a dataset with cross-validation
	 * @param classifer the classifier to be used
	 * @param data the set of instances
	 * @param folds the number of cross-validation folds
	 * @return the evaluation result
	 * @throws Exception
	 */
	public static Evaluation crossValidate(Classifier classifer, Instances data, int folds) throws Exception {
		Evaluation eval = new Evaluation(data);
		eval.crossValidateModel(classifer, data, folds, new Random(1)); 
		return eval;
	}
	

	/**
	 * Cross-validate a set of models on a dataset 
	 * @param classifiers the array of classifiers to use
	 * @param data the dataset
	 * @param folds the number of folds to use in cross-validation
	 * @return an Evaluation object with the results
	 * @throws Exception
	 */
	public static Evaluation[] evaluateClassifiers(Classifier[] classifiers, Instances data, int folds) throws Exception {
		Evaluation[] results = new Evaluation[classifiers.length];
		for(int i = 0; i < results.length; i++) {
			results[i] = crossValidate(classifiers[i], data, folds);
		}
		return results;
	}
	
	/**
	 * Find best result from list of cross-validation results based on f-measure
	 * @param results the Evalation objects to search
	 * @return the best Evaluation object
	 */
	public static int bestResult(Evaluation[] results) throws Exception {
		int best = 0;
		for(int i = 0; i < results.length; i++){
			if (results[i].weightedFMeasure() > results[best].weightedFMeasure())
				best = i;
		}
		return best;
	}
	
	/**
	 * Basic parameter tuning for some common classifiers
	 * @param classifiers the classifiers to optimize
	 * @param data the dataset
	 * @return and array of classifiers with better parameter values
	 * @throws Exception
	 */
	public static Classifier[] optimizeClassifiers(Classifier[] classifiers, Instances data) throws Exception{
		for(int i = 0; i < classifiers.length; i++){
			System.out.println("Optimizing: " + classifiers[i].getClass().toString());
			CVParameterSelection optimizedClassifier = new CVParameterSelection();
			optimizedClassifier.setNumFolds(10);
			optimizedClassifier.setClassifier(classifiers[i]);
			if (classifiers[i] instanceof AdaBoostM1) {
				optimizedClassifier.addCVParameter("P 50 250 5");
			}
			else if (classifiers[i] instanceof Bagging){
				optimizedClassifier.addCVParameter("P 50 100 3");
				optimizedClassifier.addCVParameter("I 10 50 5");
			}
			else if (classifiers[i] instanceof J48){
				optimizedClassifier.addCVParameter("C 0.1 0.5 5");
				optimizedClassifier.addCVParameter("M 1 20 1");
			}
			else if (classifiers[i] instanceof IBk){
				optimizedClassifier.addCVParameter("K 1 20 1");
			}
			else if (classifiers[i] instanceof LMT){
				optimizedClassifier.addCVParameter("M 5 35 7");
			}
			else if (classifiers[i] instanceof LogitBoost){
				optimizedClassifier.addCVParameter("I 10 50 5");
				optimizedClassifier.addCVParameter("H .1 1 10");
			}
			else if(classifiers[i] instanceof MultilayerPerceptron){
				optimizedClassifier.addCVParameter("L 0.1 0.5 5");
				optimizedClassifier.addCVParameter("M 0.1 0.5 5");
			}
			else if (classifiers[i] instanceof RandomForest) {
				optimizedClassifier.addCVParameter("I 5 20 4");
				optimizedClassifier.addCVParameter("K 0 " + Math.max(20, data.numAttributes()-1) + " 1");
			}
			else if (classifiers[i] instanceof SMO){
				optimizedClassifier.addCVParameter("C .1 10.1 10");
				if(((SMO)classifiers[i]).getKernel() instanceof RBFKernel){
					optimizedClassifier.addCVParameter("G .01 1.01 10");
				}
			}else if (classifiers[i] instanceof Logistic) {
				optimizedClassifier.addCVParameter("M 10 100 10");
			}

			optimizedClassifier.buildClassifier(data);
			System.out.println(Utils.joinOptions(optimizedClassifier.getBestClassifierOptions()));
		}
		return classifiers;
	}
	
	
	/**
	 * Remove a percentage of a dataset for easy testing
	 * @param data the set of instances
	 * @param percentage the percent of the data to remove
	 * @return the dataset without x% of its instances
	 */
	public static Instances removePercentage(Instances data, double percentage) throws Exception{
		RemovePercentage rp = new RemovePercentage();
		rp.setInputFormat(data);
		rp.setPercentage(percentage);
		return Filter.useFilter(data, rp);
	}
	

	
}
