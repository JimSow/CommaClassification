package edu.ccnu.tools.weka;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import edu.ccnu.feature.CommaFeature;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffSaver;

public class InstancesTools {
	
	/**根据已有的instances生成新的instances(只复制了已有的instances的属性信息)
	 * @param commaFeatureList
	 * @param rootInstances
	 * @return
	 */
	public static Instances generateInstancesByInstances(List<CommaFeature> commaFeatureList,Instances rootInstances) {
		Instances instances=new Instances(rootInstances, 0);
		instances.setClassIndex(instances.numAttributes()-1);
		setEachInstanceValue(commaFeatureList, instances);
		return instances;
	}
	
	public static Instances generateInstances(List<CommaFeature> commaFeatureList){
		ArrayList<String> temp=null;
		ArrayList<Attribute> attributeList=new ArrayList<>();
		attributeList.add(new Attribute("position"));
		attributeList.add(new Attribute("preTermNature", temp));
		attributeList.add(new Attribute("preTermLength"));
		attributeList.add(new Attribute("nextTermNature",temp));
		attributeList.add(new Attribute("nextTermLength"));
		attributeList.add(new Attribute("preClauseLength"));
		attributeList.add(new Attribute("nextClauseLength"));
		attributeList.add(new Attribute("preClauseDigitLetter"));
		attributeList.add(new Attribute("nextClauseDigitLetter"));
		attributeList.add(new Attribute("preClauseTermQuantity"));
		attributeList.add(new Attribute("nextClauseTermQuantity"));
		attributeList.add(new Attribute("preClauseSPQuantity"));
		attributeList.add(new Attribute("nextClauseSPQuantity"));
		attributeList.add(new Attribute("commaType",temp));
		//初始化instances
		Instances instances=new Instances("comma-ambiguation", attributeList, 0);
		instances.setClassIndex(instances.numAttributes()-1);
		setEachInstanceValue(commaFeatureList, instances);
		return instances;
	}

	/**
	 * @param commaFeatureList
	 * @param attributeList
	 * @param instances
	 */
	private static void setEachInstanceValue(List<CommaFeature> commaFeatureList,Instances instances) {
		for (CommaFeature commaFeature : commaFeatureList) {
			Instance instance=new DenseInstance(instances.numAttributes());
			//需要先指定instance归属于的dataset,然后才能往dataset中添加数据
			instance.setDataset(instances);
			instance.setValue(0, commaFeature.getPosition());
			instance.setValue(1, commaFeature.getPreTermNature());
			instance.setValue(2, commaFeature.getPreTermLength());
			instance.setValue(3, commaFeature.getNextTermNature());
			instance.setValue(4, commaFeature.getNextTermLength());
			instance.setValue(5, commaFeature.getPreClauseLength());
			instance.setValue(6, commaFeature.getNextClauseLength());
			instance.setValue(7, commaFeature.getPreClauseDigitLetter());
			instance.setValue(8, commaFeature.getNextClauseDigitLetter());
			instance.setValue(9, commaFeature.getPreClauseTermQuantity());
			instance.setValue(10, commaFeature.getNextClauseTermQuantity());
			instance.setValue(11, commaFeature.getPreClauseSPQuantity());
			instance.setValue(12, commaFeature.getNextClauseSPQuantity());
			instance.setValue(13, commaFeature.getCommaType().name());
			instances.add(instance);
		}
	}
	
	public static void generateArffFile(Instances instances, String path){
		ArffSaver saver=new ArffSaver();
		saver.setInstances(instances);
		try {
			saver.setFile(new File(path));
			saver.writeBatch();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
}
