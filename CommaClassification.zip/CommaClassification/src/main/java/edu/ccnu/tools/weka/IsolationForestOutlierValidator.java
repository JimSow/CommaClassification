package edu.ccnu.tools.weka;

import java.util.Enumeration;

import weka.classifiers.misc.IsolationForest;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SerializationHelper;

public class IsolationForestOutlierValidator implements IOutlierValidator{

	private String iForestModelPath;
	private String pos2vecModelPath;
	private double scoreThreshold;
	private IsolationForest iForest;
		
	public IsolationForestOutlierValidator(String iForestModelPath, String pos2vecModelPath, double scoreThreshold) {
		super();
		this.iForestModelPath = iForestModelPath;
		this.pos2vecModelPath=pos2vecModelPath;
		this.scoreThreshold = scoreThreshold;
		loadIsolationForestModel(iForestModelPath);
	}

	/**  
	 * <p>Title: loadIsolationForestModel</p>  
	 * <p>Description: 加载IForest模型</p>  
	 * @param iForestModelPath  
	 */  
	private void loadIsolationForestModel(String iForestModelPath) {
		try {
			this.iForest=(IsolationForest) SerializationHelper.read(iForestModelPath);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean isOutlier(Instance instance) {
		Instances sample=instance.dataset().stringFreeStructure();
		sample.insertAttributeAt(new Attribute("preTermNatureCosine"), sample.numAttributes()-1);
		sample.insertAttributeAt(new Attribute("nextTermNatureCosine"), sample.numAttributes()-1);

		double[] values = new double[sample.numAttributes()];
		Enumeration<Attribute> attributes=sample.enumerateAttributes();
		while (attributes.hasMoreElements()) {
			Attribute attribute = (Attribute) attributes.nextElement();
			if (attribute.name().equalsIgnoreCase("preTermNatureCosine")) {
				values[attribute.index()]=POS2VecHandler.getPOS2VecHandler(pos2vecModelPath).getPOSCosineValue(instance.stringValue(1));
			}else if (attribute.name().equalsIgnoreCase("nextTermNatureCosine")) {
				values[attribute.index()]=POS2VecHandler.getPOS2VecHandler(pos2vecModelPath).getPOSCosineValue(instance.stringValue(3));
			}else {
				values[attribute.index()]=instance.value(attribute);
			}
		}
		values[sample.classIndex()]=instance.classValue();
		Instance newInstance=new DenseInstance(1.0,values);
		newInstance.setDataset(sample);
		sample.add(newInstance);
		sample.deleteAttributeAt(4);
		sample.deleteAttributeAt(2);
		sample.deleteAttributeAt(0);
		
		double score=getScore(sample.firstInstance());
		if (score>=scoreThreshold) {
			return false;
		}
		return true;
	}



	/**  
	 * <p>Title: getScore</p>  
	 * <p>Description: 获取实例在Forest模型中的得分</p>  
	 * @param instance
	 * @return  
	 */  
	private double getScore(Instance instance) {
		double[] scores=iForest.distributionForInstance(instance);
		if (scores.length>0) {
			return scores[0];
		}
		return 0;
	}
	
	public String getiForestModelPath() {
		return iForestModelPath;
	}

	public void setiForestModelPath(String iForestModelPath) {
		this.iForestModelPath = iForestModelPath;
	}

	public double getScoreThreshold() {
		return scoreThreshold;
	}

	public void setScoreThreshold(double scoreThreshold) {
		this.scoreThreshold = scoreThreshold;
	}

	public IsolationForest getiForest() {
		return iForest;
	}

	public void setiForest(IsolationForest iForest) {
		this.iForest = iForest;
	}
	
	public String getPos2vecModelPath() {
		return pos2vecModelPath;
	}

	public void setPos2vecModelPath(String pos2vecModelPath) {
		this.pos2vecModelPath = pos2vecModelPath;
	}
}
