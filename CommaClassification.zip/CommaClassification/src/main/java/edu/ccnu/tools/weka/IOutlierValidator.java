package edu.ccnu.tools.weka;

import weka.core.Instance;

public interface IOutlierValidator {

	/**  
	 * <p>Title: isValid</p>  
	 * <p>Description: 检验一个实例是否为outlier</p>  
	 * @param instance
	 * @return  
	 */  
	boolean isOutlier(Instance instance);
	
}
