package edu.ccnu.feature;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.corpus.dependency.CoNll.CoNLLSentence;
import com.hankcs.hanlp.corpus.dependency.CoNll.CoNLLWord;
import com.hankcs.hanlp.dependency.nnparser.NeuralNetworkDependencyParser;
import com.hankcs.hanlp.seg.common.Term;

public class FeatureSelection {
	
	private String originalText;
	private ArrayList<CommaType> commaTypes=new ArrayList<>();
		
	public FeatureSelection(String originalText){
		this.originalText=originalText;
		getCommaTypes();
	}
	
	public FeatureSelection(File file) throws IOException {
		super();
		this.setOriginalText(FileUtils.readFileToString(file, "utf-8"));
		getCommaTypes();
	}

	public ArrayList<CommaFeature> getAllCommaFeatures(){
		ArrayList<CommaFeature> result=new ArrayList<>();
		//去除类别标记和把英文逗号转成中文逗号
		String text=getQuestionText(originalText).replaceAll(",", "，");
		ArrayList<Integer> commaIndexList=getCommaIndex(text);
		ArrayList<String> clauseList=getClauseListByComma(text, commaIndexList);
		int temp=0;
		for (Integer commaIndex : commaIndexList) {
			String preClause=getPreNextClause(temp,clauseList,true);
			String nextClause=getPreNextClause(temp+1,clauseList,false);
			CommaFeature comma=generateComma(commaIndex,preClause,nextClause);
			result.add(comma);
			temp++;
		}
		return result;
	}

	/**
	 * @param index
	 * @param preClause
	 * @param nextClause
	 * @return
	 * 根据逗号前后子句生成逗号的特征
	 */
	private CommaFeature generateComma(Integer index, String preClause,
			String nextClause) {
		CommaFeature comma=new CommaFeature();
		List<Term> preClauseTermList=HanLP.segment(preClause);
		List<Term> nextClauseTermList=HanLP.segment(nextClause);
		CommaType commaType=this.commaTypes.remove(0);
		Term preTerm=getPreNextTerm(preClauseTermList,true);
		Term nextTerm=getPreNextTerm(nextClauseTermList,false);
		comma.setPosition(index);
		comma.setPreClauseLength(preClause.length());
		comma.setPreClauseDigitLetter(hasDigitOrLetters(preClause));
		comma.setPreTermNature(preTerm.nature.name());
		comma.setPreTermLength(preTerm.length());
		comma.setPreClauseTermQuantity(preClauseTermList.size());
		comma.setPreClauseSPQuantity(getSubjectPredicateQuantity(preClause));
		comma.setNextClauseLength(nextClause.length());
		comma.setNextClauseDigitLetter(hasDigitOrLetters(nextClause));
		comma.setNextTermNature(nextTerm.nature.name());
		comma.setNextTermLength(nextTerm.length());
		comma.setNextClauseTermQuantity(nextClauseTermList.size());
		comma.setNextClauseSPQuantity(getSubjectPredicateQuantity(nextClause));
		comma.setCommaType(commaType);
//		System.out.println(comma);
		return comma;
	}


	private void getCommaTypes() {
		String regex="[#|$]";
		Pattern pattern=Pattern.compile(regex);
		Matcher matcher=pattern.matcher(this.originalText);
		while (matcher.find()) {
			String typeFlag=matcher.group(0);
			if (typeFlag.equalsIgnoreCase("#")) {
				this.commaTypes.add(CommaType.EOS);
			}else {
				this.commaTypes.add(CommaType.NONEOS);
			}
		}
	}

	private int getSubjectPredicateQuantity(String clause) {
		int result=0;
		String svStr="主谓关系";
		CoNLLSentence cSentence=NeuralNetworkDependencyParser.compute(clause);
		for (CoNLLWord word : cSentence) {
			if (StringUtils.equals(word.DEPREL, svStr)) {
				result++;
			}
		}
		return result;
	}

	/**
	 * @param clause
	 * @param isPreOrNext
	 * @return
	 * 获取逗号前后的词条term
	 */
	private Term getPreNextTerm(List<Term> termList, boolean isPreOrNext) {
		if (isPreOrNext) {
			return termList.get(termList.size()-1);
		}else {
			return termList.get(0);
		}
	}

	/**
	 * @param clause
	 * @return
	 * 利用正则表达式判断子句中是否包含有数字或字母
	 */
	private int hasDigitOrLetters(String clause) {
		String regex="[a-z0-9A-Z]+";
		Pattern p=Pattern.compile(regex);
		Matcher matcher=p.matcher(clause);
		if (matcher.find()) {
			return 1;
		}else {
			return 0;
		}
	}

	/**
	 * @param index
	 * @param clauseList
	 * @param isPreOrNext true表示获取Pre,false则是Next
	 * @return
	 * 获取逗号前后的子句
	 */
	private String getPreNextClause(Integer index,
			ArrayList<String> clauseList, boolean isPreOrNext) {
		String clauseStr=clauseList.get(index);
		String[] clauseSpecificArr=clauseStr.split("[!|.|?|;|！|。|？|；]");
		if (isPreOrNext) {
			int length=clauseSpecificArr.length;
			return clauseSpecificArr[length-1];
		}else {
			return clauseSpecificArr[0];
		}
		
	}


	/**
	 * @param text
	 * @param commaIndex
	 * @return
	 * 根据逗号分割文本成子句clause
	 */
	private ArrayList<String> getClauseListByComma(String text, ArrayList<Integer> commaIndex) {
		ArrayList<String> clauseList=new ArrayList<>();
		int temp=0;
		for (Integer index : commaIndex) {
			String clause=text.substring(temp, index);
			clauseList.add(clause);
			temp=index+1;
		}
		clauseList.add(text.substring(temp));
		return clauseList;
	}
		
	/**
	 * @param text
	 * @return
	 * 获取逗号在文本中所有位置索引
	 */
	private ArrayList<Integer> getCommaIndex(String text) {
		ArrayList<Integer> result=new ArrayList<>();
		int lastIndex=text.lastIndexOf("，");
		for (int i=-1;i<=lastIndex; ++i) {
			i=text.indexOf("，", i);
			result.add(i);
		}
//		System.out.println(result);
		return result;
	}

	/**
	 * @return
	 * @throws IOException
	 * 读取问题文本，并过滤掉文本中的空格，逗号的类别号
	 */
	private String getQuestionText(String text){
		text=StringUtils.replaceAll(text, "[\\s|#|$]", "");
		return text;
	}


	public String getOriginalText() {
		return originalText;
	}

	public void setOriginalText(String originalText) {
		this.originalText = originalText;
	}
	
	
	
}
