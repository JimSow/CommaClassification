package edu.ccnu.feature;

public class CommaFeature {
	//类别，分两类:EOS，NON-EOS
	private CommaType commaType;
	//文本中的位置
	private int position;
	//逗号前一个词的词性
	private String preTermNature;
	//逗号前一个词的长度
	private int preTermLength;
	//逗号后一个词的词性
	private String nextTermNature;
	//逗号后一个词的长度
	private int nextTermLength;
	//逗号前一个子句的长度
	private int preClauseLength;
	//逗号后一个子句的长度
	private int nextClauseLength;
	//逗号前一个子句是否包含数字或字母,1表示有，0表示无
	private int preClauseDigitLetter;
	//逗号后一个子句是否包含数字或字母,1表示有，0表示无
	private int nextClauseDigitLetter;
	//逗号前一个子句的词条数
	private int preClauseTermQuantity;
	//逗号后一个子句的词条数
	private int nextClauseTermQuantity;
	//逗号前一个子句的主谓关系数量
	private int preClauseSPQuantity;
	//逗号后一个子句的主谓关系数量
	private int nextClauseSPQuantity;
	
	public CommaFeature() {
	}
	
	public CommaType getCommaType() {
		return commaType;
	}

	public void setCommaType(CommaType commaType) {
		this.commaType = commaType;
	}

	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String getPreTermNature() {
		return preTermNature;
	}
	public void setPreTermNature(String preTermNature) {
		this.preTermNature = preTermNature;
	}
	public int getPreTermLength() {
		return preTermLength;
	}

	public void setPreTermLength(int preTermLength) {
		this.preTermLength = preTermLength;
	}

	public String getNextTermNature() {
		return nextTermNature;
	}
	public void setNextTermNature(String nextTermNature) {
		this.nextTermNature = nextTermNature;
	}
	public int getNextTermLength() {
		return nextTermLength;
	}

	public void setNextTermLength(int nextTermLength) {
		this.nextTermLength = nextTermLength;
	}

	public int getPreClauseLength() {
		return preClauseLength;
	}
	public void setPreClauseLength(int preClauseLength) {
		this.preClauseLength = preClauseLength;
	}
	public int getNextClauseLength() {
		return nextClauseLength;
	}
	public void setNextClauseLength(int nextClauseLength) {
		this.nextClauseLength = nextClauseLength;
	}
	public int getPreClauseDigitLetter() {
		return preClauseDigitLetter;
	}
	public void setPreClauseDigitLetter(int preClauseDigitLetter) {
		this.preClauseDigitLetter = preClauseDigitLetter;
	}
	public int getNextClauseDigitLetter() {
		return nextClauseDigitLetter;
	}
	public void setNextClauseDigitLetter(int nextClauseDigitLetter) {
		this.nextClauseDigitLetter = nextClauseDigitLetter;
	}


	public int getPreClauseTermQuantity() {
		return preClauseTermQuantity;
	}

	public void setPreClauseTermQuantity(int preClauseTermQuantity) {
		this.preClauseTermQuantity = preClauseTermQuantity;
	}

	public int getNextClauseTermQuantity() {
		return nextClauseTermQuantity;
	}

	public void setNextClauseTermQuantity(int nextClauseTermQuantity) {
		this.nextClauseTermQuantity = nextClauseTermQuantity;
	}

	public int getPreClauseSPQuantity() {
		return preClauseSPQuantity;
	}

	public void setPreClauseSPQuantity(int preClauseSPQuantity) {
		this.preClauseSPQuantity = preClauseSPQuantity;
	}

	public int getNextClauseSPQuantity() {
		return nextClauseSPQuantity;
	}

	public void setNextClauseSPQuantity(int nextClauseSPQuantity) {
		this.nextClauseSPQuantity = nextClauseSPQuantity;
	}

	@Override
	public String toString() {
		return String
				.format("CommaFeature [commaType=%s, position=%s, preTermNature=%s, preTermLength=%s, nextTermNature=%s, nextTermLength=%s, preClauseLength=%s, nextClauseLength=%s, preClauseDigitLetter=%s, nextClauseDigitLetter=%s, preClauseTermQuantity=%s, nextClauseTermQuantity=%s, preClauseSPQuantity=%s, nextClauseSPQuantity=%s]",
						commaType, position, preTermNature, preTermLength,
						nextTermNature, nextTermLength, preClauseLength,
						nextClauseLength, preClauseDigitLetter,
						nextClauseDigitLetter, preClauseTermQuantity,
						nextClauseTermQuantity, preClauseSPQuantity,
						nextClauseSPQuantity);
	}

	
	
}
