package edu.ccnu.feature;

public enum CommaType {
	EOS,NONEOS; 
}
