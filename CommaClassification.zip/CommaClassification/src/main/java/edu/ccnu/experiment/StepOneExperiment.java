package edu.ccnu.experiment;

import java.util.Random;

import edu.ccnu.tools.weka.FeatureEngineeringUtils;
import edu.ccnu.tools.weka.WekaUtils;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.meta.CVParameterSelection;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.Utils;
import weka.filters.supervised.instance.Resample;
import weka.filters.supervised.instance.SpreadSubsample;

public class StepOneExperiment extends Experiment {
	
	public static void main(String[] args) throws Exception {
		//加载数据
		Instances initData=loadData();
		//数据预处理
		Instances dataAfterPreprocessing=preProcessingData(initData);
//		System.out.println(dataAfterPreprocessing.toSummaryString());
//		System.out.println(dataAfterPreprocessing.firstInstance());
		//SMOTE处理不平衡数据和优化随机森林树的超参数
		Integer[] parameterKForSmote= {3,4,5,6,7,8,9};
		Integer[] parameterPForSmote= {100,200,300,400,500};
		//把数据拆分成训练集和测试集
		dataAfterPreprocessing.randomize(new Random(1));
		int trainSize = (int) Math.round(dataAfterPreprocessing.numInstances() * 0.6);
		int validationSize=(int) Math.round(dataAfterPreprocessing.numInstances()*0.2);
        int testSize = dataAfterPreprocessing.numInstances() - trainSize-validationSize;  
        Instances train = new Instances(dataAfterPreprocessing, 0, trainSize);
        Instances validation=new Instances(dataAfterPreprocessing, trainSize, validationSize);
        Instances test = new Instances(dataAfterPreprocessing, trainSize+validationSize, testSize);
        RandomForest  randomForest=new RandomForest();
        randomForest.setNumExecutionSlots(0);
        FeatureEngineeringUtils.ClassStatistics(train);
        
//        randomForestWithBoostrapSampling(train,validation,randomForest);
//        randomForestWithUndersampling(train, validation, randomForest);
//        randomForestWithSMOTE(parameterKForSmote, parameterPForSmote, train, validation, randomForest);
		randomForestWithForestSMOTE(parameterKForSmote, parameterPForSmote, train, validation, randomForest);
	}

	private static void randomForestWithBoostrapSampling(Instances train, Instances validation,
			RandomForest randomForest) throws Exception {
//		for(int i=1;i<36;i++) {
//			String[] options= {""}
//		}
		Resample resample=new Resample();
		resample.setSampleSizePercent(50.0);
		resample.setInputFormat(train);
		Instances resamplingData=resample.useFilter(train, resample);
		FeatureEngineeringUtils.ClassStatistics(resamplingData);
	}

	/**
	 * @param train
	 * @param validation
	 * @param randomForest
	 * @throws Exception
	 */
	private static void randomForestWithUndersampling(Instances train, Instances validation, RandomForest randomForest)
			throws Exception {
		Instances underSamplingData=underSampling(train);
        FeatureEngineeringUtils.ClassStatistics(underSamplingData);
        randomForestEval(underSamplingData, validation, randomForest);
	}

	/**
	 * @param train
	 * @throws Exception
	 */
	private static Instances underSampling(Instances train) throws Exception {
		SpreadSubsample sps = new SpreadSubsample();  
        sps.setMaxCount(101); //minority class的样本数量 n  
        sps.setInputFormat(train);  
        Instances underSamplingData = sps.useFilter(train, sps);
        return underSamplingData;
	}

	/**
	 * @param parameterKForSmote
	 * @param parameterPForSmote
	 * @param train
	 * @param validation
	 * @param randomForest
	 * @throws Exception
	 */
	private static void randomForestWithSMOTE(Integer[] parameterKForSmote, Integer[] parameterPForSmote,
			Instances train, Instances validation, RandomForest randomForest) throws Exception {
		for (Integer P : parameterPForSmote) {
			for (Integer K : parameterKForSmote) {
				Instances balancedTrainData=balanceData(train, P, K);
				FeatureEngineeringUtils.ClassStatistics(train);
				FeatureEngineeringUtils.ClassStatistics(balancedTrainData);
				System.out.println("P="+P+" K="+K+";");
				randomForestEval(balancedTrainData, validation, randomForest);
			}			
		}
	}
	
	private  static void randomForestWithForestSMOTE(Integer[] parameterKForSmote, Integer[] parameterPForSmote,
			Instances train, Instances validation, RandomForest randomForest) throws Exception {
		for (Integer P : parameterPForSmote) {
			for (Integer K : parameterKForSmote) {
				Instances balancedTrainData=balanceDataByForestSMOTE(train, P, K);
				FeatureEngineeringUtils.ClassStatistics(train);
				FeatureEngineeringUtils.ClassStatistics(balancedTrainData);
				System.out.println("P="+P+" K="+K+";");
				randomForestEval(balancedTrainData, validation, randomForest);
			}			
		}
		
	}

	/**
	 * @param train
	 * @param validation
	 * @param randomForest
	 * @throws Exception
	 */
	private static void randomForestEval(Instances train, Instances validation, RandomForest randomForest)
			throws Exception {
		//imbalance data
        Classifier optimalRandomForest=optimizeRandomForest(randomForest, train);
        Evaluation evaluation=new Evaluation(validation);
		evaluation.evaluateModel(optimalRandomForest, validation);
		outputEvaluation(evaluation);
	}
	
	private static Classifier optimizeRandomForest(Classifier randomForest, Instances data) throws Exception {
			CVParameterSelection optimizedClassifier=new CVParameterSelection();
			optimizedClassifier.setNumFolds(10);
			optimizedClassifier.setClassifier(randomForest);
			optimizedClassifier.addCVParameter("I 5 100 20");
			optimizedClassifier.addCVParameter("K 0 15 16");
			optimizedClassifier.buildClassifier(data);
			System.out.println(optimizedClassifier.toString());
			System.out.println("Best parameters:"+Utils.joinOptions(optimizedClassifier.getBestClassifierOptions()));
			return randomForest;
	}

	private static Instances preProcessingData(Instances data) throws Exception {
		/*
		 * 特征工程
		 */
		// 删除mwpId属性
		Instances newData = FeatureEngineeringUtils.useRemoveFilter(data, "1");
		// 生成交叉特征
		newData = FeatureEngineeringUtils.generateCrossingFeature(newData);
		// 把newData中的string属性转换nominal属性
		newData = FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes() - 3));
		newData = FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes() - 2));
		newData.setRelationName("data");
		return newData;
	}
	
	private static Instances balanceData(Instances data, int P,int K) throws Exception {
		String[] options = { "-S", "1", "-P", ""+P, "-K", ""+K };
		Instances newData = FeatureEngineeringUtils.useSMOTE(data, options);
		newData.setRelationName("training balanced data");
		return newData;
	}
	
	private static Instances balanceDataByForestSMOTE(Instances data, int P,int K) throws Exception {
		String[] options = { "-S", "1", "-P", ""+P, "-K", ""+K };
		Instances newData = FeatureEngineeringUtils.useForestSMOTE(data, options);
		newData.setRelationName("training balanced data");
		return newData;
	}
	
}
