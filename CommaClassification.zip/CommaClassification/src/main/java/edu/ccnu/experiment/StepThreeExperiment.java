package edu.ccnu.experiment;

import java.io.File;
import java.nio.channels.FileLock;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import edu.ccnu.feature.CommaFeature;
import edu.ccnu.feature.FeatureSelection;
import edu.ccnu.tools.weka.FeatureEngineeringUtils;
import edu.ccnu.tools.weka.InstancesTools;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.functions.LibSVM;
import weka.classifiers.functions.Logistic;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.RandomForest;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SerializationHelper;
import weka.core.expressionlanguage.weka.InstancesHelper;

public class StepThreeExperiment extends Experiment {
	static String testDataDir="data/testData/";
//	static String modelPath="models/RF-40_1combSMOTE-400_9.model";
//	static String modelPath="models/j48.model";
//	static String modelPath="models/naiveBayes.model";
//	static String modelPath="models/logistic.model";
//	static String modelPath="models/libSVM.model";
	static String modelPath="models/RF.model";
	
	public static void main(String[] args) throws Exception {
//		File file=new File("data/testData/81.txt");
//		List<String> lines=FileUtils.readLines(file,Charset.defaultCharset());
//		int i=82;
//		for (String line : lines) {
//			FileUtils.write(new File("data/testData/"+i+".txt"), line, Charset.defaultCharset());
//			i++;
//		}
		
		
//		J48 j48=(J48) SerializationHelper.read(modelPath);
//		NaiveBayes naiveBayes=(NaiveBayes) SerializationHelper.read(modelPath);
//		Logistic logistic=(Logistic) SerializationHelper.read(modelPath);
//		LibSVM libSVM=(LibSVM) SerializationHelper.read(modelPath);
		RandomForest randomForest=(RandomForest) SerializationHelper.read(modelPath);
		Instances fittingData=loadData();
		fittingData=FeatureEngineeringUtils.useRemoveFilter(fittingData,"1");
		File dir=new File(testDataDir);
		File[] files=dir.listFiles();
		List<ArrayList<CommaFeature>> commaFeaturesList=new ArrayList<>();
		for (File file : files) {
			FeatureSelection fs=new FeatureSelection(file);
			ArrayList<CommaFeature> commaFeatures=fs.getAllCommaFeatures();
			for (CommaFeature commaFeature : commaFeatures) {
				Attribute preTermNature=fittingData.attribute("preTermNature");
				Attribute nextTermNature=fittingData.attribute("nextTermNature");
				if (preTermNature.indexOfValue(commaFeature.getPreTermNature())==-1) {
					commaFeature.setPreTermNature(preTermNature.value(0));
				}
				if (nextTermNature.indexOfValue(commaFeature.getNextTermNature())==-1) {
					commaFeature.setNextTermNature(nextTermNature.value(0));
				}
			}
			commaFeaturesList.add(commaFeatures);
		}
		List<Integer> resultList=new ArrayList<>();
		for (int i = 0; i < 200; i++) {
			Collections.shuffle(commaFeaturesList, new Random(i));
			int countAllTrue=0;
			for (int j = 0; j < 100; j++) {
				Collections.shuffle(commaFeaturesList, new Random(j));
				Instances testInstances=InstancesTools.generateInstancesByInstances(commaFeaturesList.get(j), fittingData);
				Instances newTestInstances=FeatureEngineeringUtils.generateCrossingFeature(testInstances);
				
				ArrayList<String> predictList=new ArrayList<>();
				boolean isAllTrue=true;
//				for (Instance instance : newTestInstances) {
//					if (instance.classValue()!=1.0) {
//						isAllTrue=false;
//					}
//				}
				for (Instance tempInstance : newTestInstances) {
					int actul=(int) tempInstance.classValue();
					int predict=(int) randomForest.classifyInstance(tempInstance);
					predictList.add(actul+"-"+predict);
					if (actul!=predict) {
						isAllTrue=false;
					}
				}
				if (isAllTrue) {
					countAllTrue++;
				}
//				System.out.println(StringUtils.join(predictList, "    "));
			}
			resultList.add(countAllTrue);
		}
		System.out.println(StringUtils.join(resultList,System.lineSeparator()));
	}
	

	/**
	 * @param fittingData
	 */
	private static void inspectAttributes(Instances fittingData) {
		Enumeration<Attribute> fittingDataAttributes=fittingData.enumerateAttributes();
		while (fittingDataAttributes.hasMoreElements()) {
			Attribute attribute = (Attribute) fittingDataAttributes.nextElement();
			System.out.println(attribute.toString());
			if (attribute.isNominal()) {
				Enumeration<Object> attributeValues=attribute.enumerateValues();
				while (attributeValues.hasMoreElements()) {
					Object object = (Object) attributeValues.nextElement();
					System.out.print(object+" ");
				}
				System.out.println();
			}
			
		}
	}
	
}
