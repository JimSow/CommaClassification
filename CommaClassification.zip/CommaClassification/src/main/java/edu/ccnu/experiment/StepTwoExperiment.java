package edu.ccnu.experiment;

import java.awt.Color;
import java.util.Random;

import javax.swing.JFrame;

import edu.ccnu.tools.weka.FeatureEngineeringUtils;
import edu.ccnu.tools.weka.InstancesTools;
import edu.ccnu.tools.weka.WekaUtils;
import fr.ign.cogit.roc4j.core.ReceiverOperatingCharacteristics;
import fr.ign.cogit.roc4j.graphics.RocSpace;
import fr.ign.cogit.roc4j.utils.Tools;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.evaluation.ThresholdCurve;
import weka.classifiers.functions.LibSVM;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.SMO;
import weka.classifiers.functions.supportVector.RBFKernel;
import weka.classifiers.meta.CVParameterSelection;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.RandomForest;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SerializationHelper;
import weka.core.Utils;
import weka.core.converters.ConverterUtils.DataSink;
import weka.filters.supervised.instance.SpreadSubsample;

public class StepTwoExperiment extends Experiment {

	static Instances train;
	static Instances validation;
	static Instances test;
	
	public static void main(String[] args) throws Exception {
		//加载数据
		Instances initData=loadData();
		//数据预处理
		Instances dataAfterPreprocessing=preProcessingData(initData);
		//把数据拆分成训练集和测试集
		splitDataset(dataAfterPreprocessing);
		
//		J48 j48=new J48();
//		J48 optimalClassifier=optimizeJ48(j48, train);
//		optimalClassifier.buildClassifier(train);
//		SerializationHelper.write("models/j48.model", optimalClassifier);
		
//		Logistic logistic=new Logistic();
//		Logistic optimalClassifier=optimizeLogistic(logistic, train);
//		optimalClassifier.buildClassifier(train);
//		SerializationHelper.write("models/logistic.model", optimalClassifier);
		
//		NaiveBayes naiveBayes=new NaiveBayes();
//		naiveBayes.buildClassifier(train);
//		SerializationHelper.write("models/naiveBayes.model", naiveBayes);
		
//		SMO smo=new SMO();
//		String[] options= {"-N","1"};
//		smo.setOptions(options);
//		RBFKernel rbfKernel=new RBFKernel();
//		rbfKernel.setCacheSize(0);
//		rbfKernel.setGamma(0.5);
//		smo.setKernel(rbfKernel);
//		SMO optimalClassifier=optimizeSMO(smo,train);
		
//		optimalClassifier.buildClassifier(train);
		
//		LibSVM libSVM=new LibSVM();
////		String[] options = {"-K","1","-D","5","-C","0.5"};
////		libSVM.setOptions(options);
//		LibSVM optimalClassifier=optimizeLibSVM(libSVM,train);
//		optimalClassifier.buildClassifier(train);
//		SerializationHelper.write("models/libSVM.model", optimalClassifier);
//		System.out.println(Utils.joinOptions(libSVM.getOptions()));
		
		
		RandomForest  randomForest=new RandomForest();
		randomForest.setNumExecutionSlots(0);
		Classifier optimalRandomForest=optimizeRandomForest(randomForest, train);
//		train.addAll(validation);
		optimalRandomForest.buildClassifier(train);
		SerializationHelper.write("models/RF.model", optimalRandomForest);
		
		
//		RandomForest  randomForest=new RandomForest();
//        randomForest.setNumExecutionSlots(0);
//		Instances balancedTrainData=balanceData(train, 400, 9);
//        Instances balancedTrainData=underSampling(train);
//		Classifier optimalRandomForest=optimizeRandomForest(randomForest, balancedTrainData);
//		balancedTrainData.addAll(validation);
//		optimalRandomForest.buildClassifier(balancedTrainData);
//		SerializationHelper.write("models/RF-40_1combSMOTE-400_9.model", optimalRandomForest);
		
//		//evaluation
		Evaluation evaluation=evaluationClassifier(optimalRandomForest,test);
		outputEvaluation(evaluation);
//		//output roc data
//		String fileName="C:/Users/admin/Desktop/roc4RF+SMOTE(P=400, K=9).csv";
//		outputRocData(evaluation,fileName);

	}
	
	
	/**under sampling
	 * 
	 * @param train
	 * @return
	 * @throws Exception
	 */
	private static Instances underSampling(Instances train) throws Exception {
		SpreadSubsample sps = new SpreadSubsample();  
        sps.setMaxCount(101); //minority class的样本数量 n  
        sps.setInputFormat(train);  
        Instances underSamplingData = sps.useFilter(train, sps);
        return underSamplingData;
	}
	
	private static Classifier optimizeRandomForest(Classifier randomForest, Instances data) throws Exception {
		CVParameterSelection optimizedClassifier=new CVParameterSelection();
		optimizedClassifier.setNumFolds(10);
		optimizedClassifier.setClassifier(randomForest);
		optimizedClassifier.addCVParameter("I 5 100 20");
		optimizedClassifier.addCVParameter("K 0 15 16");
		optimizedClassifier.buildClassifier(data);
		System.out.println(optimizedClassifier.toString());
		System.out.println("Best parameters:"+Utils.joinOptions(optimizedClassifier.getBestClassifierOptions()));
		return randomForest;
}
	
	private static Instances balanceData(Instances data, int P,int K) throws Exception {
		String[] options = { "-S", "1", "-P", ""+P, "-K", ""+K };
		Instances newData = FeatureEngineeringUtils.useSMOTE(data, options);
		newData.setRelationName("training balanced data");
		return newData;
	}
	
	/** 优化libSVM
	 * @param libSVM
	 * @param trainData
	 * @return
	 * @throws Exception
	 */
	private static LibSVM optimizeLibSVM(LibSVM libSVM, Instances trainData) throws Exception {
		CVParameterSelection cvps=new CVParameterSelection();
		cvps.setNumFolds(10);
		cvps.setClassifier(libSVM);
		cvps.addCVParameter("G 0.001 0.01 10");
		cvps.addCVParameter("D 0 5 6");
		cvps.addCVParameter("R 0.1 1 10");
		cvps.buildClassifier(trainData);
		System.out.println(cvps.toString());
		System.out.println("Best parameters:"+Utils.joinOptions(cvps.getBestClassifierOptions()));
		return libSVM;
	}


	/**优化SMO
	 * @param smo
	 * @param trainData
	 * @return
	 * @throws Exception
	 */
	private static SMO optimizeSMO(SMO smo, Instances trainData) throws Exception {
		CVParameterSelection cvps=new CVParameterSelection();
		cvps.setNumFolds(10);
		cvps.setClassifier(smo);
		cvps.addCVParameter("C 1 10 10");
//		cvps.addCVParameter("L 0.001 0.1 100");
		cvps.buildClassifier(trainData);
		System.out.println(cvps.toString());
		System.out.println("Best parameters:"+Utils.joinOptions(cvps.getBestClassifierOptions()));
		return smo;
	}
	
	
	/** 优化Logistic
	 * @param logistic
	 * @param trainData
	 * @return
	 * @throws Exception
	 */
	private static Logistic optimizeLogistic(Logistic logistic, Instances trainData) throws Exception {
		CVParameterSelection cvps=new CVParameterSelection();
		cvps.setNumFolds(10);
		cvps.setClassifier(logistic);
		cvps.addCVParameter("M 1 100 100");
		cvps.buildClassifier(trainData);
		System.out.println(cvps.toString());
		System.out.println("Best parameters:"+Utils.joinOptions(cvps.getBestClassifierOptions()));
		return logistic;
	}
	
	private static void visualizeROC4J(Evaluation evaluation) {
		ThresholdCurve tc = new ThresholdCurve();
		int classIndex = 1;
		Instances result = tc.getCurve(evaluation.predictions(), classIndex);
		int tpIndex = result.attribute(ThresholdCurve.TP_RATE_NAME).index();
		int fpIndex = result.attribute(ThresholdCurve.FP_RATE_NAME).index();
		double[] tpRate = result.attributeToDoubleArray(tpIndex);
		double[] fpRate = result.attributeToDoubleArray(fpIndex);
		ReceiverOperatingCharacteristics roc=new ReceiverOperatingCharacteristics(fpRate,tpRate);
		String text = Tools.round(100*roc.computeAUC(), 1)+" %";
		roc.smooth(ReceiverOperatingCharacteristics.SMOOTH_BINORMAL_REGRESSION);
		RocSpace space = new RocSpace();
		space.setTitle("Area Under Curve");
		space.setXLabel("False Positive Rate");
		space.setYLabel("True Positive Rate");
		
		int x = 450;
		int y = 450;
		space.writeText(text, x, y, 20, Color.GREEN.darker());
		space.addRocCurve(roc);
		
		
		JFrame fen = new JFrame();
		fen.setSize(700, 700);
		fen.setContentPane(space);
		fen.setLocationRelativeTo(null);
		fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fen.setVisible(true);
	}

	/**
	 * @param evaluation
	 * @throws Exception
	 */
	private static void outputRocData(Evaluation evaluation, String fileName) throws Exception {
		ThresholdCurve tc = new ThresholdCurve();
		// classIndex is the index of the class to consider as "positive"
		int classIndex = 0;
		Instances result = tc.getCurve(evaluation.predictions(), classIndex);
		System.out.println("The area under the ROC　curve: " + evaluation.areaUnderROC(classIndex));
		DataSink.write(fileName, result);
	}


	/**
	 * @param optimalClassifier
	 * @return 
	 * @throws Exception
	 */
	private static Evaluation evaluationClassifier(Classifier optimalClassifier,Instances evalData) throws Exception {
		Evaluation evaluation=new Evaluation(evalData);
		evaluation.evaluateModel(optimalClassifier, evalData);
		return evaluation;
	}


	/** 优化 j48
	 * @param j48
	 * @param trainData
	 * @return
	 * @throws Exception
	 */
	private static J48 optimizeJ48(J48 j48, Instances trainData) throws Exception {
		CVParameterSelection cvps=new CVParameterSelection();
		cvps.setNumFolds(10);
		cvps.setClassifier(j48);
		cvps.addCVParameter("C 0.05 0.5 10");
		cvps.addCVParameter("M 1 20 20");
		cvps.buildClassifier(trainData);
		System.out.println(cvps.toString());
		System.out.println("Best parameters:"+Utils.joinOptions(cvps.getBestClassifierOptions()));
		return j48;
	}


	/**
	 * @param dataAfterPreprocessing
	 */
	private static void splitDataset(Instances dataAfterPreprocessing) {
		dataAfterPreprocessing.randomize(new Random(1));
		int trainSize = (int) Math.round(dataAfterPreprocessing.numInstances() * 0.6);
		int validationSize=(int) Math.round(dataAfterPreprocessing.numInstances()*0.2);
		int testSize = dataAfterPreprocessing.numInstances() - trainSize-validationSize;  
		train = new Instances(dataAfterPreprocessing, 0, trainSize);
		validation=new Instances(dataAfterPreprocessing, trainSize, validationSize);
		test = new Instances(dataAfterPreprocessing, trainSize+validationSize, testSize);
	}


	private static Instances preProcessingData(Instances data) throws Exception {
		/*
		 * 特征工程
		 */
		// 删除mwpId属性
		Instances newData = FeatureEngineeringUtils.useRemoveFilter(data, "1");
		// 生成交叉特征
		newData = FeatureEngineeringUtils.generateCrossingFeature(newData);
		// 把newData中的string属性转换nominal属性
		newData = FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes() - 3));
		newData = FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes() - 2));
		newData.setRelationName("data");
		return newData;
	}
	
	
}
