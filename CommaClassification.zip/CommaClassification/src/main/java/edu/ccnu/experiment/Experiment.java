package edu.ccnu.experiment;

import edu.ccnu.tools.weka.WekaUtils;
import weka.classifiers.Evaluation;
import weka.core.Instances;

public class Experiment {
	static String username = "root";
	static String password = "hjx123456789";
	static String dburl = "jdbc:mysql://127.0.0.1:3306/mathwordproblems" + "?useUnicode=true&characterEncoding=UTF8";
	
	protected static Instances loadData() throws Exception {
		String sql = "select * from stratifiedcommafeature";
		Instances data = WekaUtils.loadInstancesFromDB(username, password, dburl, sql);
		return data;
	}
	
	protected static void outputEvaluation(Evaluation evaluation) throws Exception {
		System.out.println(evaluation.toSummaryString(false));
		System.out.println(evaluation.toClassDetailsString());
		System.out.println(evaluation.toMatrixString());
	}
}
