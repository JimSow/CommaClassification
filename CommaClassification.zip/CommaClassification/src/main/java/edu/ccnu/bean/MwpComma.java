package edu.ccnu.bean;

public class MwpComma {
	private int id;
	private String stratifiedNarrative;
	private String stratifiedCommaLabel;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStratifiedNarrative() {
		return stratifiedNarrative;
	}
	public void setStratifiedNarrative(String stratifiedNarrative) {
		this.stratifiedNarrative = stratifiedNarrative;
	}
	public String getStratifiedCommaLabel() {
		return stratifiedCommaLabel;
	}
	public void setStratifiedCommaLabel(String stratifiedCommaLabel) {
		this.stratifiedCommaLabel = stratifiedCommaLabel;
	}
	@Override
	public String toString() {
		return "MwpComma [id=" + id + ", stratifiedNarrative=" + stratifiedNarrative + ", stratifiedCommaLabel="
				+ stratifiedCommaLabel + "]";
	}
	
	
}
