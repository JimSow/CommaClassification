import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.io.FileUtils;

import com.sun.org.apache.bcel.internal.generic.NEW;

import edu.ccnu.bean.MwpComma;
import edu.ccnu.common.utils.JdbcUtils;
import edu.ccnu.feature.CommaFeature;
import edu.ccnu.feature.FeatureSelection;
import junit.framework.TestCase;

@SuppressWarnings("unused")
public class TestInsertMWPs extends TestCase {
	public  void test() throws SQLException, IOException {

//		insert("E:\\学习\\个人论文.获奖\\Using Classification Methods to Leverage Semantic Labeling of Elementary Discourse Units from Math Word Problems\\"
//				+ "raw-data\\commaData\\");
//		insert("data/TestRawData");
		insertCommaFeature2DB();
//		System.out.println("Complie succeed");
	}
	private void insertCommaFeature2DB() throws SQLException {
		List<MwpComma> mwpCommas=getMwpComma();
		String sql="insert into stratifiedcommafeature(mwpId,position,preTermNature,preTermLength,nextTermNature," + 
				"nextTermLength,preClauseLength,nextClauseLength,preClauseDigitLetter,nextClauseDigitLetter," + 
				"preClauseTermQuantity,nextClauseTermQuantity,preClauseSPQuantity,nextClauseSPQuantity,commaType) values"
				+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
		QueryRunner qRunner=new QueryRunner(JdbcUtils.getDataSource());
		int i=0;
		for (MwpComma mwpComma : mwpCommas) {
			FeatureSelection fs=new FeatureSelection(mwpComma.getStratifiedCommaLabel());
			ArrayList<CommaFeature> commaFeatures=fs.getAllCommaFeatures();
			for (CommaFeature commaFeature : commaFeatures) {
				System.out.println(commaFeature);
				Object[] params= {mwpComma.getId(),commaFeature.getPosition(),commaFeature.getPreTermNature(),commaFeature.getPreTermLength(),
						commaFeature.getNextTermNature(),commaFeature.getNextTermLength(),commaFeature.getPreClauseLength(),
						commaFeature.getNextClauseLength(),commaFeature.getPreClauseDigitLetter(),commaFeature.getNextClauseDigitLetter(),
						commaFeature.getPreClauseTermQuantity(),commaFeature.getNextClauseTermQuantity(),commaFeature.getPreClauseSPQuantity(),
						commaFeature.getNextClauseSPQuantity(),commaFeature.getCommaType().toString()
				};
				qRunner.update(sql, params);
			}
			i++;
			System.out.println("已完成第"+i+"个文件的特征构造……");
		}
	}
	private void insert(String path) throws IOException, SQLException {
		QueryRunner qr=new QueryRunner(JdbcUtils.getDataSource());
		String sql="insert into stratifiedmwps(id,stratifiedNarrative,stratifiedCommaLabel) values(?,?,?);";
		File dir=new File(path);
		File[] files=dir.listFiles();
		int i=1;
		for (File file : files) {
			String commaLabelText=FileUtils.readFileToString(file, "utf-8");
			String text=commaLabelText.replaceAll("[#|$]", "");
			Object[] params= {i,text,commaLabelText};
			qr.update(sql,params);
			System.out.println("第"+i+"文件");
			i++;
		}
	}
	
	private List<MwpComma> getMwpComma() throws SQLException{
		String sql="select * from stratifiedmwps where id>235;";
		QueryRunner qRunner=new QueryRunner(JdbcUtils.getDataSource());
		BeanListHandler<MwpComma> hlh=new BeanListHandler<>(MwpComma.class);
		List<MwpComma> result=(List<MwpComma>) qRunner.query(sql,hlh);
		return result;
	}
}
