import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import com.hankcs.hanlp.corpus.document.CorpusLoader;
import com.hankcs.hanlp.corpus.document.CorpusLoader.HandlerThread;
import com.hankcs.hanlp.corpus.document.Document;
import com.hankcs.hanlp.corpus.document.sentence.word.IWord;

import junit.framework.TestCase;

public class TestHanlp extends TestCase {

	private String corpusDir = "F:/语料/人民日报语料/2014/train+develop";
	private String outPutPOSFilePath="F:/语料/人民日报语料/2014/pos.txt";
	private String outPutWordsFilePath="F:/语料/人民日报语料/2014/words.txt";

	public void testHanlp() {
		extractWordsFromCorpus();
	}
	
	
	/**  
	 * <p>Title: extractWordsFromCorpus</p>  
	 * <p>Description: 从语料库中提出词条序列</p>    
	 */  
	private void extractWordsFromCorpus() {
		File outputFile=new File(outPutWordsFilePath);
		HandlerThread[] handlerThreadArray = new CorpusLoader.HandlerThread[4];
		for (int i = 0; i < handlerThreadArray.length; ++i) {
			handlerThreadArray[i] = new HandlerThread(String.valueOf(i)) {
				@Override
				public void handle(Document document) {
					List<List<IWord>> complexSentenceList=document.getComplexSentenceList();
					List<String> wordList=new LinkedList<String>();
					for (List<IWord> sentence : complexSentenceList) {
						for (IWord word : sentence) {
							wordList.add(word.getValue());
						}
						try {
							if (wordList.size()>0) {
								FileUtils.write(outputFile, StringUtils.join(wordList, " ")+System.lineSeparator(), "utf-8", true);
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						wordList.clear();
					}
				}
			};
		}
		CorpusLoader.walk(corpusDir, handlerThreadArray);
	}
	

	/**  
	 * <p>Title: extractPOSFromCorpus</p>  
	 * <p>Description: 从语料库中提取出词性序列</p>    
	 */  
	private void extractPOSFromCorpus() {
		File outputFile=new File(outPutPOSFilePath);
		HandlerThread[] handlerThreadArray = new CorpusLoader.HandlerThread[4];
		for (int i = 0; i < handlerThreadArray.length; ++i) {
			handlerThreadArray[i] = new HandlerThread(String.valueOf(i)) {
				@Override
				public void handle(Document document) {
					List<List<IWord>> complexSentenceList=document.getComplexSentenceList();
					List<String> posList=new LinkedList<String>();
					for (List<IWord> sentence : complexSentenceList) {
						for (IWord word : sentence) {
							posList.add(word.getLabel());
						}
						try {
							if (posList.size()>0) {
								FileUtils.write(outputFile, StringUtils.join(posList, " ")+System.lineSeparator(), "utf-8", true);
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						posList.clear();
					}
				}
			};
		}
		CorpusLoader.walk(corpusDir, handlerThreadArray);
	}

	
	
}
