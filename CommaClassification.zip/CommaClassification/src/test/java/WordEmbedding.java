import java.io.File;
import java.util.Collection;

import org.deeplearning4j.models.embeddings.loader.WordVectorSerializer;
import org.deeplearning4j.models.word2vec.Word2Vec;
import org.deeplearning4j.text.sentenceiterator.LineSentenceIterator;
import org.deeplearning4j.text.sentenceiterator.SentenceIterator;
import org.deeplearning4j.text.tokenization.tokenizer.preprocessor.CommonPreprocessor;
import org.deeplearning4j.text.tokenization.tokenizerfactory.DefaultTokenizerFactory;
import org.deeplearning4j.text.tokenization.tokenizerfactory.TokenizerFactory;

public class WordEmbedding {
	
//	private static final String corpusPath = "F:/语料/人民日报语料/2014/words.txt";
	private static final String corpusPath = "F:/语料/word2vec/zhwiki_1710_preprocessed.simplied.txt";
	private static final String vectorsPath = "F:/语料/人民日报语料/2014/words_vectors_wiki_300.bin";
	
	public static void useWordEmbedding() {
		System.out.println("Start Loading...");
        long st = System.currentTimeMillis();
		Word2Vec word2Vec=WordVectorSerializer.readWord2VecModel(new File(vectorsPath));
		long et = System.currentTimeMillis();
        System.out.println("Loading is completed, and the time-cost is " + (et-st)/1000 + " s.");
//		
//		double[] baseVector=new double[300];
//		for (int i = 0; i < baseVector.length; i++) {
//			baseVector[i]=1.0;	
//		}
		
//		double[] vector=word2Vec.getWordVector("n");
        long st2 = System.currentTimeMillis();
		System.out.println(word2Vec.wordsNearest("华中师范大学", 20));
		long et2 = System.currentTimeMillis();
		System.out.println("Finding the nearest words is completed, and the time-cost is " + (et2-st2)/1000 + " s.");
//		System.out.println("s: "+word2Vec.similarity("苹果", "梨子"));
	}
	
	public static void main(String[] args) {
		

//		trainWordEmbedding();
		useWordEmbedding();

	}

	/**  
	 * <p>Title: trainPOSEmbedding</p>  
	 * <p>Description: </p>    
	 */  
	private static void trainWordEmbedding() {
		System.out.println("Start Training...");
        long st = System.currentTimeMillis();

        System.out.println("Load & vectorize sentences...");
        SentenceIterator iter = new LineSentenceIterator(new File(corpusPath));
        TokenizerFactory t = new DefaultTokenizerFactory();
        t.setTokenPreProcessor(new CommonPreprocessor());

        System.out.println("Building model...");
        Word2Vec vec = new Word2Vec.Builder()
                .minWordFrequency(10)
                .epochs(10)
                .iterations(1)
                .layerSize(200)
                .seed(42)
                .windowSize(5)
                .iterate(iter)
                .tokenizerFactory(t)
                .workers(4)
                .build();

        System.out.println("Fitting word2vec model...");
        vec.fit();

        System.out.println("Writing word vectors to text file...");
        WordVectorSerializer.writeWord2VecModel(vec, vectorsPath);

        System.out.println("Closest Words:");
        Collection<String> wordsList1 = vec.wordsNearest("微信", 10);
        Collection<String> wordsList2 = vec.wordsNearest("运动员", 10);
        System.out.println(wordsList1);
        System.out.println(wordsList2);

        long et = System.currentTimeMillis();
        System.out.println("Training is completed, and the time taken is " + (et-st)/1000 + " s.");
	}
	
	

}
