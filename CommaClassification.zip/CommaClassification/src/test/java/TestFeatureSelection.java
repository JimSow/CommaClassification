import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.corpus.dependency.CoNll.CoNLLSentence;
import com.hankcs.hanlp.dependency.nnparser.NeuralNetworkDependencyParser;
import com.hankcs.hanlp.seg.common.Term;

import weka.core.Instances;
import edu.ccnu.feature.CommaFeature;
import edu.ccnu.feature.FeatureSelection;
import edu.ccnu.tools.weka.InstancesTools;
import junit.framework.TestCase;


public class TestFeatureSelection extends TestCase {
	public void test() throws IOException{
//		String path="./data/";
//		File dir=new File(path);
//		File[] files=dir.listFiles();
//		ArrayList<CommaFeature> allCommaFeatures=new ArrayList<>();
//		for (File file : files) {
//			System.out.println(FilenameUtils.getBaseName(file.getAbsolutePath()));
//			FeatureSelection fs=new FeatureSelection(file.getAbsolutePath());
//			ArrayList<CommaFeature> commaFeatures=fs.getAllCommaFeatures();
//			allCommaFeatures.addAll(commaFeatures);
//		}
//		System.out.println(allCommaFeatures.size());
//		Instances instances=InstancesTools.generateInstances(allCommaFeatures);
//		InstancesTools.generateArffFile(instances, "C:/Users/USER/Desktop/commaData.arff");
		List<Term> terms=HanLP.segment("已知该学院的A专业有380名学生");
		System.out.println(terms);
		
//		File mwpFile=new File("./data/1.txt");
//		FeatureSelection fs=new FeatureSelection(mwpFile);
//		ArrayList<CommaFeature> commaFeatures=fs.getAllCommaFeatures();
//		int i=1;
//		for (CommaFeature commaFeature : commaFeatures) {
//			System.out.println(i+". "+commaFeature);
//			i++;
//		}

	}
	private boolean isValid(String text) {
		int flags=getFlag(text,"[#|$]");
		int commasQ=getFlag(text, "[,|，]");
//		System.out.println(flags);
//		System.out.println(commasQ);
		if (flags==commasQ) {
			return true;
		}
		return false;
	}
	private int getFlag(String text, String regex) {
		int result=0;
				
		Pattern pattern=Pattern.compile(regex);
		Matcher matcher=pattern.matcher(text);
		while (matcher.find()) {
			result++;
		}
		return result;
	}

	private String getText(File file) throws IOException {
		String text=FileUtils.readFileToString(file,"utf-8");
		return text;
	}
}
