
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang.ObjectUtils.Null;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.util.MathUtils;
import org.deeplearning4j.models.embeddings.loader.WordVectorSerializer;
import org.deeplearning4j.models.word2vec.Word2Vec;
import org.nd4j.nativeblas.Nd4jCpu.l2_loss;

import edu.ccnu.tools.weka.FeatureEngineeringUtils;
import edu.ccnu.tools.weka.ForestSMOTE;
import edu.ccnu.tools.weka.IOutlierValidator;
import edu.ccnu.tools.weka.IsolationForestOutlierValidator;
import edu.ccnu.tools.weka.WekaUtils;
import junit.framework.TestCase;
import weka.classifiers.Classifier;
import weka.classifiers.trees.RandomForest;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.ConverterUtils.DataSink;
import weka.filters.Filter;
import weka.filters.unsupervised.instance.Resample;
import weka.filters.supervised.instance.SMOTE;
import weka.filters.unsupervised.attribute.Remove;

public class TestWekaQueryDB extends TestCase{
	private String modelPath="F:/语料/人民日报语料/2014/pos_vectors_300.bin";
	double[] baseVec=new double[300];
	private Word2Vec word2Vec=null;
	public void test() throws Exception {
		init();
		
		queryDB();
//		Random rand=new Random(47);  
//        Integer[] ia={0,1,2,3,4,5,6,7,8,9};  
//        List<Integer> list=new ArrayList<Integer>(Arrays.asList(ia));  
//        System.out.println("Before shufflig: "+list);  
//        Collections.shuffle(list,rand);  
//        System.out.println("After shuffling: "+list);  
//        System.out.println("array: "+Arrays.toString(ia));  
//        List<Integer> list1=Arrays.asList(ia);  
//        System.out.println("Before shuffling: "+list1);  
//        Collections.shuffle(list1,rand);  
//        System.out.println("After shuffling: "+list1);  
//        System.out.println("array: "+Arrays.toString(ia)); 
//        
//        for (int i = 0; i < 10; i++) {
//        	Collections.shuffle(list1,rand); 
//            System.out.println("After shuffling: "+list1);
//		}
          

	}

	/**  
	 * <p>Title: init</p>  
	 * <p>Description: </p>    
	 */  
	private void init() {
		for (int i = 0; i < baseVec.length; i++) {
			baseVec[i]=1.0;
		}
		setWord2Vec();
	}

	private void queryDB() throws Exception {
		String username="root";
		String password="hjx123456789";
		String dburl="jdbc:mysql://127.0.0.1:3306/mathwordproblems"
				+ "?useUnicode=true&characterEncoding=UTF8";
		String sql = "select * from stratifiedcommafeature";
		Instances data =WekaUtils.loadInstancesFromDB(username,password,dburl,sql);
		data.setClassIndex(data.numAttributes()-1);
		System.out.println(data.toSummaryString());
//		Instances newData=WekaUtils.loadInstances("./data/cleanData/commaData.arff");
				
//		data.insertAttributeAt(new Attribute("preTermNatureCosine"), data.numAttributes()-1);
//		data.insertAttributeAt(new Attribute("nextTermNatureCosine"), data.numAttributes()-1);
//		for (Instance instance : data) {
//			String pos1=instance.stringValue(data.attribute("preTermNature"));
//			String pos2=instance.stringValue(data.attribute("nextTermNature"));
//			instance.setValue(data.attribute("preTermNatureCosine"), getCosineValue(pos1));
//			instance.setValue(data.attribute("nextTermNatureCosine"), getCosineValue(pos2));
//		}
		ClassStatistics(data);
		Integer[] delArr=new Integer[] {0};
		FeatureEngineeringUtils.removeAttributes(data, Arrays.asList(delArr));
		System.out.println("Using SMOTE:");
		Instances smoteData=useSMOTE(data);
		ClassStatistics(smoteData);
		System.out.println("Using ForestSMOTE:");
		Instances forestSmoteData=useForestSMOTE(data);
		ClassStatistics(forestSmoteData);
		
//		data.deleteAttributeAt(4);
//		data.deleteAttributeAt(2);
//		data.deleteAttributeAt(0);
//		Instances dta=FeatureEngineeringUtils.useRemoveFilter(data,"1 3 5");
//		newData=FeatureEngineeringUtils.useRemoveFilter(newData, "2");
//		newData=FeatureEngineeringUtils.useRemoveFilter(newData, "3");
		
//		Instances subsetData=FeatureEngineeringUtils.useSubsetByExpressionFilter(data, "CLASS is \'EOS\'");
//		System.out.println(subsetData.toSummaryString());
		
//		newData=FeatureEngineeringUtils.generateCrossingFeature(newData);
//		System.out.println(newData.toSummaryString());
//		newData=FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes()-3));
//		newData=FeatureEngineeringUtils.useString2NominalFilter(newData, String.valueOf(newData.numAttributes()-2));
//		System.out.println(newData.toSummaryString());
//
//		newData=useSMOTE(newData);
//		newData.setRelationName("balanceData");
//		System.out.println(newData.toSummaryString());
//		ClassStatistics(newData);
//		
//		newData=WekaUtils.selectFeaturesCFS(newData);
//		System.out.println(newData.toSummaryString());
		
//		Instances cfsData=WekaUtils.selectFeaturesCFS(newData);
//		System.out.println("after featureselection:-------------------------------------");
//		outputAttributes(cfsData);
//		Classifier rf=new RandomForest();
//		Classifier[] classifiers=new Classifier[1];
//		classifiers[0]=rf;
//		Classifier[] optClassfiers=WekaUtils.optimizeClassifiers(classifiers, cfsData);
//		System.out.println(optClassfiers[0]);
	}
	
	
	private void setWord2Vec() {
		if (word2Vec == null) {
			synchronized (modelPath) {
				word2Vec=WordVectorSerializer.readWord2VecModel(modelPath);
			}
		}
	}
	
	
	/**  
	 * <p>Title: getCosineValue</p>  
	 * <p>Description: 计算基向量与词性向量在词性语义空间中的余弦值</p>  
	 * @param vec1
	 * @param vec2
	 * @return  
	 */  
	private double getCosineValue(String pos1) {
		double[] posVec=word2Vec.getWordVector(pos1);
		if (posVec==null) {
			return 1.0;
		}
		RealVector realVector1=new ArrayRealVector(posVec);
		RealVector realVector2=new ArrayRealVector(baseVec);
		return realVector1.cosine(realVector2);
	}

	private void ClassStatistics(Instances data) {
		int eos=0;
		int noneos=0;
		for (Instance instance : data) {
			String clazz=instance.stringValue(instance.classIndex());
			if (clazz.equalsIgnoreCase("eos")) {
				eos++;
			}else if (clazz.equalsIgnoreCase("noneos")) {
				noneos++;
			}
		}
		System.out.println("EOS:"+eos+"\t"+"NONEOS:"+noneos);
	}

	private Instances useSMOTE(Instances data) throws Exception {
		SMOTE smote=new SMOTE();
		String[] options= {"-S","1","-P","100.0","-K","4"};
		smote.setOptions(options);
		smote.setInputFormat(data);
		Instances newData=Filter.useFilter(data, smote);
		return newData;
	}
	
	private Instances useForestSMOTE(Instances data) throws Exception {
		String eosIForestModel="F:/语料/人民日报语料/2014/iForest-EOSCommas.model";
		String noneosIForestModel="F:/语料/人民日报语料/2014/iForest-NONEOSCommas.model";	
		String pos2vecModelPath="F:/语料/人民日报语料/2014/pos_vectors_300.bin";
		
		IsolationForestOutlierValidator forestOutlierValidator1=new IsolationForestOutlierValidator(noneosIForestModel, pos2vecModelPath, 0.5);
		IsolationForestOutlierValidator forestOutlierValidator2=new IsolationForestOutlierValidator(eosIForestModel, pos2vecModelPath, 0.5);
		HashMap<IOutlierValidator, Boolean> outlierMap=new HashMap<>();
		outlierMap.put(forestOutlierValidator1, false);
		outlierMap.put(forestOutlierValidator2, true);
		ForestSMOTE forestSmote=new ForestSMOTE(outlierMap);
		
		String[] options= {"-S","1","-P","100.0","-K","4"};
		forestSmote.setOptions(options);
		forestSmote.setInputFormat(data);
		Instances newData=Filter.useFilter(data, forestSmote);
		return newData;
	}
	
	private Instances useResample(Instances data) throws Exception {
		Resample resample=new Resample();
		String[] options= {"-S","1"};
		resample.setOptions(options);
		resample.setInputFormat(data);
		Instances newData=Filter.useFilter(data, resample);
		return newData;
	}

	
/*-I 10 -P 100 -num-slots 1 -K 0 -M 1.0 -V 0.001 -S 1
 * 
-P 100 -I 40 -num-slots 1 -K 0 -M 1.0 -V 0.001 -S 1
RandomForest

Bagging with 40 iterations and base learner

weka.classifiers.trees.RandomTree -K 0 -M 1.0 -V 0.001 -S 1 -do-not-check-capabilities
 * 
 * */	
	

	
	
}
