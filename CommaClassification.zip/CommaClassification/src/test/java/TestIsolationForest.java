import edu.ccnu.tools.weka.IsolationForestOutlierValidator;
import edu.ccnu.tools.weka.WekaUtils;
import weka.classifiers.misc.IsolationForest;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SerializationHelper;

public class TestIsolationForest {

	private static String dataPath="F:/语料/人民日报语料/2014/EOSCommas.arff";
	private static String testDataPath="F:/语料/人民日报语料/2014/NONEOSCommas.arff";
	//IsolationForest模型的序列化路径
	private static String eosIForestModel="F:/语料/人民日报语料/2014/iForest-EOSCommas.model";
	private static String noneosIForestModel="F:/语料/人民日报语料/2014/iForest-NONEOSCommas.model";
	private static String allIForestModel="F:/语料/人民日报语料/2014/iForest-allCommas.model";
	
	private static String pos2vecModelPath="F:/语料/人民日报语料/2014/pos_vectors_300.bin";
	
	public static void main(String[] args) throws Exception {;
		useIForest();
	}

	private static void useIForest() throws Exception {
		//loading data
//		Instances data1=WekaUtils.loadInstances(testDataPath);
//		Instances data=WekaUtils.loadInstances(dataPath);
//		data.addAll(data1);
//		System.out.println(data.toSummaryString());
		
//		IsolationForest iForest=new IsolationForest();
//		String[] options=new String[2];
//		options[0]="-N";
//		options[1]="1000";
//		iForest.setOptions(options);
//		iForest.buildClassifier(data);
//		
//		for (Instance instance : data) {
//			double[] scores=iForest.distributionForInstance(instance);
//			System.out.println(scores[0]);
//		}
//		SerializationHelper.write(eosIForestModel, iForest);
		String username="root";
		String password="hjx123456789";
		String dburl="jdbc:mysql://127.0.0.1:3306/mathwordproblems"
				+ "?useUnicode=true&characterEncoding=UTF8";
		String sql = "select * from stratifiedcommafeature";
		Instances data =WekaUtils.loadInstancesFromDB(username,password,dburl,sql);
		data.setClassIndex(data.numAttributes()-1);
		
//		IsolationForest iForest1=(IsolationForest) SerializationHelper.read(noneosIForestModel);
//		IsolationForest iForest2=(IsolationForest) SerializationHelper.read(eosIForestModel);
		System.out.println("结果：");
		IsolationForestOutlierValidator outlierValidator=new IsolationForestOutlierValidator(noneosIForestModel, pos2vecModelPath, 0.5);
		double counter=0;
		for (Instance instance : data) {
//			double score1=IsolationForestValidator.getScoreFromIForestModel(instance, iForest1);
//			double score2=IsolationForestValidator.getScoreFromIForestModel(instance, iForest2);
			if (outlierValidator.isOutlier(instance)==false) {
//				System.out.println("Score1 is "+score1+"; Score2 is "+score2+".");
				counter++;
			}
		}
		System.out.println(counter);
//		System.out.println("------------------------------------");


	}

}
